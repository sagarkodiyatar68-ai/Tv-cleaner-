pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // libadb-android, sun-security-android and spake2-android are published through JitPack.
        maven("https://jitpack.io")
    }
}

rootProject.name = "TVCleaner"
include(":app")
