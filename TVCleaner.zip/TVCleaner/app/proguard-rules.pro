# Release builds do not shrink (see build.gradle.kts). These rules only matter if you turn minify on.
-keep class io.github.muntashirakon.adb.** { *; }
-keep class org.conscrypt.** { *; }
-keep class android.sun.** { *; }
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
