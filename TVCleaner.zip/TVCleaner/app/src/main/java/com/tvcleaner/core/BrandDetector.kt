package com.tvcleaner.core

object BrandDetector {
    /**
     * Guesses the TV brand from Android build properties.
     * [manufacturer] ro.product.manufacturer, [brand] ro.product.brand,
     * [model] ro.product.model, [device] ro.product.device.
     */
    fun detect(manufacturer: String, brand: String, model: String, device: String): Brand {
        val all = "$manufacturer $brand $model $device".lowercase()
        return when {
            "shield" in all || "nvidia" in all -> Brand.NVIDIA_SHIELD
            "chromecast" in all || device.lowercase() in GOOGLE_TV_DEVICES -> Brand.CHROMECAST_GTV
            "haier" in all || "candy" in all -> Brand.HAIER
            "tcl" in all -> Brand.TCL
            "xiaomi" in all || "mitv" in all || "mibox" in all || "redmi" in all -> Brand.XIAOMI
            "sony" in all || "bravia" in all -> Brand.SONY
            "hisense" in all || "hismart" in all || "vidaa" in all -> Brand.HISENSE
            "philips" in all || "tpvision" in all || "tp vision" in all || "tpv" in all -> Brand.PHILIPS
            else -> Brand.OTHER
        }
    }

    /** Device codenames: Chromecast with Google TV 4K (sabrina) / HD (boreal), Google TV Streamer (kirkwood). */
    private val GOOGLE_TV_DEVICES = setOf("sabrina", "boreal", "kirkwood")
}
