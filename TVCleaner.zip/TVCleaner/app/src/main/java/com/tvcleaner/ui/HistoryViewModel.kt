package com.tvcleaner.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tvcleaner.AppContainer
import com.tvcleaner.data.db.BatchWithItems
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HistoryViewModel(private val container: AppContainer) : ViewModel() {
    private val dao = container.database.restoreDao()
    private val repo get() = container.repository

    val batches: StateFlow<List<BatchWithItems>> =
        dao.observeBatches().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val restorableCount: StateFlow<Int> =
        dao.observeRestorableCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    val connected = container.session.state

    val runner = ApplyRunner(viewModelScope)

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun dismissMessage() {
        _message.value = null
    }

    private fun requireConnection(): Boolean {
        if (container.session.isConnected) return true
        _message.update { "Connect to the TV first (Connect tab), then restore." }
        return false
    }

    fun restoreAll() {
        if (!requireConnection()) return
        runner.run("Restore all", repo.restoreAll())
    }

    fun restoreBatch(id: Long) {
        if (!requireConnection()) return
        runner.run("Restore batch", repo.restoreBatch(id))
    }

    fun deleteBatch(id: Long) {
        viewModelScope.launch { dao.deleteBatch(id) }
    }

    fun clearHistory() {
        viewModelScope.launch { dao.clearAll() }
    }
}
