package com.tvcleaner.core

data class Outcome(val success: Boolean, val message: String)

/** Parsers for the text the TV's shell returns. Pure functions, covered by unit tests. */
object ShellParser {
    const val EXIT_MARKER = "__tvc_rc="

    private val COMPONENT = Regex("^([A-Za-z_][A-Za-z0-9_]*(?:\\.[A-Za-z_][A-Za-z0-9_]*)*)/[A-Za-z0-9_.$]+$")
    private val PROP = Regex("^\\[(.+?)]: \\[(.*)]$")

    fun normalize(raw: String): String = raw.replace("\r\n", "\n").replace('\r', '\n')

    /** Splits `output + marker` into the real output and the exit code (null if the marker is missing). */
    fun splitExit(raw: String): Pair<String, Int?> {
        val text = normalize(raw)
        val idx = text.lastIndexOf(EXIT_MARKER)
        if (idx < 0) return text.trimEnd() to null
        val tail = text.substring(idx + EXIT_MARKER.length).trim()
        val code = tail.takeWhile { it.isDigit() }.toIntOrNull()
        return text.substring(0, idx).trimEnd() to code
    }

    fun parsePackages(output: String): Set<String> {
        val result = LinkedHashSet<String>()
        for (line in normalize(output).lineSequence()) {
            val l = line.trim()
            if (!l.startsWith("package:")) continue
            var p = l.removePrefix("package:")
            if ('=' in p) p = p.substringAfterLast('=')
            p = p.trim()
            if (CommandBuilder.isValidPackage(p)) result.add(p)
        }
        return result
    }

    fun parseGetprop(output: String): Map<String, String> {
        val map = HashMap<String, String>()
        for (line in normalize(output).lineSequence()) {
            val m = PROP.matchEntire(line.trim()) ?: continue
            map[m.groupValues[1]] = m.groupValues[2]
        }
        return map
    }

    fun parseTvInfo(props: Map<String, String>): TvInfo {
        fun p(vararg keys: String) = keys.firstNotNullOfOrNull { props[it]?.takeIf(String::isNotBlank) } ?: ""
        val manufacturer = p("ro.product.manufacturer", "ro.product.vendor.manufacturer")
        val brand = p("ro.product.brand", "ro.product.vendor.brand")
        val model = p("ro.product.model", "ro.product.vendor.model")
        val device = p("ro.product.device", "ro.product.vendor.device")
        return TvInfo(
            manufacturer = manufacturer,
            brandProp = brand,
            model = model,
            device = device,
            androidRelease = p("ro.build.version.release"),
            sdk = p("ro.build.version.sdk").toIntOrNull(),
            buildId = p("ro.build.display.id", "ro.build.id"),
            brand = BrandDetector.detect(manufacturer, brand, model, device),
        )
    }

    /** All `package/Activity` components in the output. */
    fun parseComponents(output: String): List<String> =
        normalize(output).lineSequence().map { it.trim() }.filter { COMPONENT.matches(it) }.toList()

    /**
     * Package of the default home activity from `resolve-activity --brief`.
     * Returns null when nothing is resolved or when Android answers with the chooser ("android").
     */
    fun parseHomePackage(output: String): String? {
        val comp = parseComponents(output).lastOrNull() ?: return null
        val pkg = comp.substringBefore('/')
        return pkg.takeIf { it != "android" }
    }

    fun parseHomeCandidates(output: String): Set<String> =
        parseComponents(output).map { it.substringBefore('/') }.filter { it != "android" }.toCollection(LinkedHashSet())

    /** `settings get global x` prints "null" when unset. */
    fun parseScale(output: String): Float? = normalize(output).trim().lineSequence().firstOrNull()?.trim()?.toFloatOrNull()

    /**
     * Parses `ps -A -o PID,RSS,NAME` (or classic `ps`) into app processes.
     * Only names that look like package names are returned; ":service" suffixes are stripped.
     */
    fun parseProcesses(output: String): List<ProcessInfo> {
        val lines = normalize(output).lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return emptyList()
        val header = lines.first().split(Regex("\\s+"))
        val nameIdx = header.indexOf("NAME").takeIf { it >= 0 } ?: header.lastIndex
        val rssIdx = header.indexOf("RSS").takeIf { it >= 0 }
        val byPkg = LinkedHashMap<String, ProcessInfo>()
        for (line in lines.drop(1)) {
            val cols = line.split(Regex("\\s+"))
            val name = cols.lastOrNull() ?: continue
            if (name.startsWith("/") || '.' !in name) continue
            val pkg = name.substringBefore(':')
            if (!CommandBuilder.isValidPackage(pkg)) continue
            val rss = if (rssIdx != null && rssIdx < cols.size && nameIdx == cols.lastIndex) cols[rssIdx].toLongOrNull() else null
            val old = byPkg[pkg]
            byPkg[pkg] = ProcessInfo(pkg, name, (old?.rssKb ?: 0L) + (rss ?: 0L))
        }
        return byPkg.values.toList()
    }

    private val FAILURE_MARKERS = listOf(
        "exception", "failure", "error", "not found", "unknown package", "unknown option", "unknown command",
        "permission denied", "not installed", "inaccessible", "denied",
    )

    /** Decides whether a step worked, from its output and (when known) exit code. */
    fun outcome(kind: StepKind, rawOutput: String, exitCode: Int?): Outcome {
        val text = normalize(rawOutput).trim()
        val lower = text.lowercase()
        val firstLine = text.lineSequence().firstOrNull { it.isNotBlank() }?.trim().orEmpty()
        val lines = lower.lines().map { it.trim() }
        val exitFailed = exitCode != null && exitCode != 0
        val markerFailed = FAILURE_MARKERS.any { it in lower }

        val ok = when (kind) {
            StepKind.DISABLE -> !exitFailed && "new state: disabled" in lower
            StepKind.ENABLE -> !exitFailed && "new state: enabled" in lower
            StepKind.UNINSTALL, StepKind.CLEAR_DATA, StepKind.CLEAR_CACHE ->
                !exitFailed && lines.any { it == "success" } && !markerFailed
            StepKind.INSTALL_EXISTING ->
                !exitFailed && ("installed for user" in lower || lines.any { it == "success" }) && !markerFailed
            StepKind.FORCE_STOP, StepKind.TRIM_CACHES, StepKind.SET_SETTING -> !exitFailed && !markerFailed
            StepKind.QUERY -> !exitFailed
        }
        if (ok) return Outcome(true, firstLine.ifBlank { "OK" })
        return Outcome(false, friendlyFailure(lower, firstLine, exitCode))
    }

    fun friendlyFailure(lower: String, firstLine: String, exitCode: Int?): String = when {
        "securityexception" in lower || "permission denied" in lower ->
            "Blocked by the TV: the shell isn't allowed to change this package."
        "delete_failed_device_policy_manager" in lower ->
            "Blocked by device policy on the TV."
        "unknown package" in lower || "not installed" in lower || "not found" in lower ->
            "Package isn't installed for user 0."
        "unknown option" in lower ->
            "Not supported by this Android version."
        firstLine.isNotBlank() -> firstLine
        exitCode != null -> "Command failed (exit code $exitCode)."
        else -> "Command failed."
    }
}
