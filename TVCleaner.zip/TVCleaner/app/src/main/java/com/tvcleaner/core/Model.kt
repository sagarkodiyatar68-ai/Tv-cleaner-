package com.tvcleaner.core

/** Risk level of a package. [restriction] is used to pick the most restrictive match. */
enum class Risk(val label: String, val restriction: Int) {
    SAFE("Safe", 0),
    TEST("Test", 2),
    UNKNOWN("Unknown", 1),
    PROTECTED("Protected", 3);

    companion object {
        /** Order used by filter chips. */
        val chipOrder: List<Risk> = listOf(SAFE, TEST, UNKNOWN, PROTECTED)

        fun parse(value: String): Risk =
            values().firstOrNull { it.name.equals(value.trim(), ignoreCase = true) } ?: UNKNOWN
    }
}

/** Extra flags a package can carry in addition to its risk level. */
enum class Flag(val label: String) {
    ACR_TRACKING("ACR / tracking"),
    RETAIL_DEMO("Retail demo"),
    PROMO("Promo / ads"),
    APP_STORE("App store"),
    FACTORY_TEST("Factory test");

    companion object {
        fun parse(value: String): Flag? =
            values().firstOrNull { it.name.equals(value.trim(), ignoreCase = true) }
    }
}

enum class Brand(val label: String) {
    ALL("All brands"),
    HAIER("Haier"),
    TCL("TCL"),
    XIAOMI("Xiaomi"),
    SONY("Sony"),
    HISENSE("Hisense"),
    PHILIPS("Philips"),
    NVIDIA_SHIELD("Nvidia Shield"),
    CHROMECAST_GTV("Chromecast with Google TV"),
    OTHER("Other");

    companion object {
        /** Accepts the display label ("Nvidia Shield"), the enum name ("NVIDIA_SHIELD") or "ALL". */
        fun parse(value: String): Brand? {
            val v = value.trim()
            return values().firstOrNull { it.label.equals(v, true) || it.name.equals(v, true) }
        }
    }
}

enum class PatternType { PREFIX, CONTAINS, REGEX }

data class DbEntry(
    val pkg: String,
    val name: String,
    val risk: Risk,
    val description: String,
    val brands: Set<Brand>,
    val flags: Set<Flag>,
)

data class DbPattern(
    val type: PatternType,
    val value: String,
    val risk: Risk,
    val description: String,
    val brands: Set<Brand>,
    val flags: Set<Flag>,
) {
    private val regex: Regex? = if (type == PatternType.REGEX) Regex(value) else null

    fun matches(pkg: String): Boolean = when (type) {
        PatternType.PREFIX -> pkg.startsWith(value)
        PatternType.CONTAINS -> pkg.contains(value)
        PatternType.REGEX -> regex!!.containsMatchIn(pkg)
    }
}

class PackageDb(
    val entries: List<DbEntry>,
    val patterns: List<DbPattern>,
    val version: String = "",
) {
    val byPkg: Map<String, DbEntry> = entries.associateBy { it.pkg }
}

/** Result of classifying one package. */
data class Classification(
    val pkg: String,
    val risk: Risk,
    val name: String,
    val description: String,
    val flags: Set<Flag>,
    val brands: Set<Brand>,
    /** True when the package (or one of its patterns) is covered by the database. */
    val known: Boolean,
    /** Set when the protection comes from the live TV (e.g. the active launcher). */
    val dynamicReason: String? = null,
) {
    val selectable: Boolean get() = risk != Risk.PROTECTED
}

/** Actions the user can apply to a batch of apps. */
enum class CleanAction(val label: String, val restorable: Boolean) {
    DISABLE("Disable", true),
    REMOVE("Remove", true),
    FORCE_STOP("Force stop", false),
    CLEAR_DATA("Clear data", false),
    CLEAR_CACHE("Clear cache", false);

    companion object {
        fun parse(value: String): CleanAction? =
            values().firstOrNull { it.name.equals(value.trim(), ignoreCase = true) }
    }
}

data class ScannedApp(
    val pkg: String,
    val name: String,
    val isSystem: Boolean,
    val isThirdParty: Boolean,
    val isDisabled: Boolean,
    val classification: Classification,
)

data class TvInfo(
    val manufacturer: String,
    val brandProp: String,
    val model: String,
    val device: String,
    val androidRelease: String,
    val sdk: Int?,
    val buildId: String,
    val brand: Brand,
) {
    val displayBrand: String
        get() = if (brand == Brand.OTHER || brand == Brand.ALL) {
            brandProp.ifBlank { manufacturer }.ifBlank { "Unknown" }
        } else brand.label

    val androidText: String
        get() = buildString {
            append("Android ").append(androidRelease.ifBlank { "?" })
            if (sdk != null) append(" (API ").append(sdk).append(")")
        }
}

data class ProcessInfo(val pkg: String, val processName: String, val rssKb: Long?)

data class BatchSummary(
    val timeText: String,
    val action: String,
    val total: Int,
    val succeeded: Int,
    val failed: Int,
)
