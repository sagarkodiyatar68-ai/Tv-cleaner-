package com.tvcleaner.domain

import android.content.Context
import android.graphics.Bitmap
import android.util.LruCache
import androidx.core.graphics.drawable.toBitmap
import com.tvcleaner.adb.AdbFailure
import com.tvcleaner.adb.TvSession
import com.tvcleaner.core.CommandBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File

/** App name and icon read from the TV's APK. Either part may be missing. */
data class AppVisual(val label: String?, val icon: Bitmap?)

/**
 * Loads real app names and icons by copying the app's APK from the TV and reading it with the phone's
 * PackageManager. Strictly on demand, one at a time, with a size cap; results are cached on the phone.
 */
class IconRepository(private val context: Context, private val session: TvSession) {
    private val memory = LruCache<String, AppVisual>(400)
    private val gate = Semaphore(1)
    private val dir = File(context.cacheDir, "tv_icons").apply { mkdirs() }

    fun cached(pkg: String): AppVisual? = memory.get(pkg)

    suspend fun load(pkg: String): AppVisual {
        memory.get(pkg)?.let { return it }
        readDisk(pkg)?.let {
            memory.put(pkg, it)
            return it
        }
        return gate.withPermit {
            memory.get(pkg)?.let { return@withPermit it }
            val visual = try {
                fetch(pkg)
            } catch (e: AdbFailure) {
                if (e is AdbFailure.Disconnected) throw e
                EMPTY
            }
            memory.put(pkg, visual)
            visual
        }
    }

    private suspend fun fetch(pkg: String): AppVisual {
        val pathOutput = session.shell(CommandBuilder.packagePath(pkg)).output
        val path = pathOutput.lineSequence().map { it.trim() }
            .firstOrNull { it.startsWith("package:") }
            ?.removePrefix("package:")?.trim()
        if (path == null || !CommandBuilder.isValidPath(path)) return EMPTY

        val size = session.shell(CommandBuilder.fileSize(path)).output.trim().toLongOrNull()
        if (size == null || size > MAX_APK_BYTES) return EMPTY

        val tmp = File(dir, "$pkg.apk.tmp")
        return try {
            tmp.outputStream().buffered().use { session.pullFile(path, MAX_APK_BYTES, it) }
            val visual = withContext(Dispatchers.Default) { parseApk(tmp) }
            writeDisk(pkg, visual)
            visual
        } finally {
            tmp.delete()
        }
    }

    private fun parseApk(file: File): AppVisual {
        return try {
            val pm = context.packageManager
            val info = pm.getPackageArchiveInfo(file.path, 0) ?: return EMPTY
            val appInfo = info.applicationInfo ?: return EMPTY
            appInfo.sourceDir = file.path
            appInfo.publicSourceDir = file.path
            val label = appInfo.loadLabel(pm).toString().takeIf { it.isNotBlank() }
            val icon = try {
                appInfo.loadIcon(pm).toBitmap(ICON_PX, ICON_PX)
            } catch (e: Exception) {
                null
            }
            AppVisual(label, icon)
        } catch (e: Exception) {
            EMPTY
        }
    }

    private fun readDisk(pkg: String): AppVisual? {
        val png = File(dir, "$pkg.png")
        val labelFile = File(dir, "$pkg.label")
        if (!png.exists() && !labelFile.exists()) return null
        val bitmap = if (png.exists()) android.graphics.BitmapFactory.decodeFile(png.path) else null
        val label = if (labelFile.exists()) labelFile.readText().takeIf { it.isNotBlank() } else null
        return AppVisual(label, bitmap)
    }

    private fun writeDisk(pkg: String, visual: AppVisual) {
        try {
            visual.icon?.let { bmp ->
                File(dir, "$pkg.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }
            visual.label?.let { File(dir, "$pkg.label").writeText(it) }
        } catch (_: Exception) {
            // The cache is optional.
        }
    }

    fun clearCache() {
        memory.evictAll()
        dir.listFiles()?.forEach { it.delete() }
    }

    private companion object {
        val EMPTY = AppVisual(null, null)
        const val MAX_APK_BYTES = 40L * 1024 * 1024
        const val ICON_PX = 96
    }
}
