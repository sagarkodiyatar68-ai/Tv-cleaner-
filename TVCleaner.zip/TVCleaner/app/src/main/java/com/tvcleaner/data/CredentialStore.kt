package com.tvcleaner.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.sun.security.x509.AlgorithmId
import android.sun.security.x509.CertificateAlgorithmId
import android.sun.security.x509.CertificateExtensions
import android.sun.security.x509.CertificateIssuerName
import android.sun.security.x509.CertificateSerialNumber
import android.sun.security.x509.CertificateSubjectName
import android.sun.security.x509.CertificateValidity
import android.sun.security.x509.CertificateVersion
import android.sun.security.x509.CertificateX509Key
import android.sun.security.x509.KeyIdentifier
import android.sun.security.x509.PrivateKeyUsageExtension
import android.sun.security.x509.SubjectKeyIdentifierExtension
import android.sun.security.x509.X500Name
import android.sun.security.x509.X509CertImpl
import android.sun.security.x509.X509CertInfo
import com.tvcleaner.adb.AdbCredentials
import java.io.ByteArrayInputStream
import java.io.File
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.Random
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores the phone's ADB RSA key.
 *
 * The private key is encrypted with an AES-256-GCM key that lives in the Android Keystore (never exportable)
 * and written to app-private no-backup storage. The certificate is public data and stored as-is.
 */
class CredentialStore(context: Context) {
    private val dir: File = context.noBackupFilesDir
    private val keyFile = File(dir, "adb_key.enc")
    private val certFile = File(dir, "adb_cert.der")

    @Synchronized
    fun loadOrCreate(): AdbCredentials = readExisting() ?: create()

    /** Short SHA-256 fingerprint of the certificate, to show in the UI. */
    @Synchronized
    fun fingerprint(): String {
        val cert = loadOrCreate().certificate
        val digest = MessageDigest.getInstance("SHA-256").digest(cert.encoded)
        return digest.take(8).joinToString(":") { "%02X".format(it) }
    }

    /** Deletes the key. The TV will ask to authorize the phone again. */
    @Synchronized
    fun reset() {
        keyFile.delete()
        certFile.delete()
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS)
    }

    private fun readExisting(): AdbCredentials? {
        if (!keyFile.exists() || !certFile.exists()) return null
        return try {
            val pkcs8 = decrypt(keyFile.readBytes())
            val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(pkcs8))
            val cert = CertificateFactory.getInstance("X.509").generateCertificate(ByteArrayInputStream(certFile.readBytes()))
            AdbCredentials(key, cert)
        } catch (e: Exception) {
            // Keystore entry lost (e.g. after a restore) or files corrupted: start over, the TV will ask again.
            null
        }
    }

    private fun create(): AdbCredentials {
        val generator = KeyPairGenerator.getInstance("RSA")
        generator.initialize(2048, SecureRandom())
        val pair = generator.generateKeyPair()
        val cert = selfSign(pair.public, pair.private)
        keyFile.writeBytes(encrypt(pair.private.encoded))
        certFile.writeBytes(cert.encoded)
        return AdbCredentials(pair.private, cert)
    }

    private fun selfSign(publicKey: PublicKey, privateKey: PrivateKey): Certificate {
        val algorithm = "SHA512withRSA"
        val notBefore = Date()
        val notAfter = Date(System.currentTimeMillis() + TEN_YEARS_MS)
        val x500 = X500Name("CN=TV Cleaner")

        val extensions = CertificateExtensions()
        extensions.set("SubjectKeyIdentifier", SubjectKeyIdentifierExtension(KeyIdentifier(publicKey).identifier))
        extensions.set("PrivateKeyUsage", PrivateKeyUsageExtension(notBefore, notAfter))

        val info = X509CertInfo()
        info.set("version", CertificateVersion(2))
        info.set("serialNumber", CertificateSerialNumber(Random().nextInt() and Int.MAX_VALUE))
        info.set("algorithmID", CertificateAlgorithmId(AlgorithmId.get(algorithm)))
        info.set("subject", CertificateSubjectName(x500))
        info.set("key", CertificateX509Key(publicKey))
        info.set("validity", CertificateValidity(notBefore, notAfter))
        info.set("issuer", CertificateIssuerName(x500))
        info.set("extensions", extensions)

        val cert = X509CertImpl(info)
        cert.sign(privateKey, algorithm)
        return cert
    }

    // ---- Keystore-backed AES-GCM wrapping ----

    private fun wrappingKey(): SecretKey {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return generator.generateKey()
    }

    private fun encrypt(plain: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, wrappingKey())
        return cipher.iv + cipher.doFinal(plain)
    }

    private fun decrypt(data: ByteArray): ByteArray {
        val iv = data.copyOfRange(0, IV_BYTES)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, wrappingKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(data, IV_BYTES, data.size - IV_BYTES)
    }

    private companion object {
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val ALIAS = "tvcleaner_adb_key_wrap_v1"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val IV_BYTES = 12
        const val TEN_YEARS_MS = 10L * 365 * 24 * 60 * 60 * 1000
    }
}
