package com.tvcleaner.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tvcleaner.AppContainer
import com.tvcleaner.data.ThemeMode
import com.tvcleaner.ui.connect.ConnectScreen
import com.tvcleaner.ui.history.HistoryScreen
import com.tvcleaner.ui.scan.ScanScreen
import com.tvcleaner.ui.theme.TvCleanerTheme
import com.tvcleaner.ui.tweaks.TweaksScreen

private enum class Tab(val label: String, val icon: ImageVector) {
    CONNECT("Connect", Icons.Default.Tv),
    SCAN("Scan", Icons.Default.Search),
    HISTORY("History", Icons.Default.History),
    TWEAKS("Tweaks", Icons.Default.Speed),
}

@Composable
fun AppRoot(container: AppContainer) {
    val factory = remember(container) { AppViewModelFactory(container) }
    val connectVm: ConnectViewModel = viewModel(factory = factory)
    val scanVm: ScanViewModel = viewModel(factory = factory)
    val historyVm: HistoryViewModel = viewModel(factory = factory)
    val tweaksVm: TweaksViewModel = viewModel(factory = factory)

    val theme by container.settings.themeMode.collectAsStateWithLifecycle(initialValue = ThemeMode.DARK)
    val connection by connectVm.connection.collectAsStateWithLifecycle()
    var tabIndex by rememberSaveable { mutableStateOf(0) }
    val tabs = Tab.values()

    LaunchedEffect(Unit) {
        connectVm.connected.collect {
            tabIndex = Tab.SCAN.ordinal
            scanVm.scan()
        }
    }

    TvCleanerTheme(theme) {
        Surface {
            Scaffold(
                bottomBar = {
                    NavigationBar {
                        tabs.forEachIndexed { i, tab ->
                            NavigationBarItem(
                                selected = tabIndex == i,
                                onClick = { tabIndex = i },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) },
                            )
                        }
                    }
                },
            ) { padding ->
                Box(modifier = Modifier.padding(padding)) {
                    when (tabs[tabIndex]) {
                        Tab.CONNECT -> ConnectScreen(connectVm)
                        Tab.SCAN -> ScanScreen(scanVm, connection, onGoConnect = { tabIndex = Tab.CONNECT.ordinal })
                        Tab.HISTORY -> HistoryScreen(historyVm)
                        Tab.TWEAKS -> TweaksScreen(tweaksVm)
                    }
                }
            }
        }
    }
}
