package com.tvcleaner.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [BatchEntity::class, ItemEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun restoreDao(): RestoreDao
}
