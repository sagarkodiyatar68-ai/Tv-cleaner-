package com.tvcleaner.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tvcleaner.AppContainer
import com.tvcleaner.adb.AdbFailure
import com.tvcleaner.adb.ConnectionState
import com.tvcleaner.core.HostValidator
import com.tvcleaner.data.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ConnectUiState(
    val host: String = "",
    val port: String = "5555",
    val pairPort: String = "",
    val pairCode: String = "",
    val busy: Boolean = false,
    val error: String? = null,
    val keyFingerprint: String = "",
)

class ConnectViewModel(private val container: AppContainer) : ViewModel() {
    private val _ui = MutableStateFlow(ConnectUiState())
    val ui: StateFlow<ConnectUiState> = _ui.asStateFlow()

    val connection: StateFlow<ConnectionState> = container.session.state

    private val _connected = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val connected: SharedFlow<Unit> = _connected.asSharedFlow()

    init {
        viewModelScope.launch {
            val prefs = container.settings.connection.first()
            _ui.update { it.copy(host = prefs.host, port = prefs.port.toString(), pairPort = prefs.pairPort) }
        }
        refreshFingerprint()
    }

    private fun refreshFingerprint() {
        viewModelScope.launch {
            val fp = withContext(Dispatchers.Default) { runCatching { container.credentials.fingerprint() }.getOrDefault("") }
            _ui.update { it.copy(keyFingerprint = fp) }
        }
    }

    fun onHost(v: String) = _ui.update { it.copy(host = v.filter { c -> !c.isWhitespace() }, error = null) }
    fun onPort(v: String) = _ui.update { it.copy(port = v.filter(Char::isDigit).take(5), error = null) }
    fun onPairPort(v: String) = _ui.update { it.copy(pairPort = v.filter(Char::isDigit).take(5), error = null) }
    fun onPairCode(v: String) = _ui.update { it.copy(pairCode = v.filter(Char::isDigit).take(6), error = null) }

    fun connect() {
        val s = _ui.value
        if (s.busy) return
        val host = s.host.trim()
        val port = s.port.toIntOrNull()
        val hostError = HostValidator.validate(host)
        if (hostError != null) {
            _ui.update { it.copy(error = hostError) }
            return
        }
        if (port == null || port !in 1..65535) {
            _ui.update { it.copy(error = "Enter a port between 1 and 65535 (default 5555).") }
            return
        }
        val wantsPairing = s.pairCode.isNotEmpty()
        val pairPort = s.pairPort.toIntOrNull()
        if (wantsPairing && (s.pairCode.length != 6 || pairPort == null || pairPort !in 1..65535)) {
            _ui.update { it.copy(error = "Pairing needs the 6-digit code and the pairing port shown on the TV.") }
            return
        }

        viewModelScope.launch {
            _ui.update { it.copy(busy = true, error = null) }
            try {
                if (wantsPairing) {
                    container.session.pair(host, pairPort!!, s.pairCode)
                    _ui.update { it.copy(pairCode = "") }
                }
                container.session.connect(host, port)
                container.settings.saveConnection(host, port, s.pairPort)
                _ui.update { it.copy(busy = false) }
                _connected.tryEmit(Unit)
            } catch (e: AdbFailure) {
                _ui.update { it.copy(busy = false, error = e.userMessage) }
            } catch (e: Exception) {
                _ui.update { it.copy(busy = false, error = e.message ?: "Unexpected error.") }
            }
        }
    }

    fun disconnect() = container.session.disconnect()

    fun resetKey() {
        container.session.disconnect()
        container.credentials.reset()
        refreshFingerprint()
    }

    fun setTheme(mode: ThemeMode) {
        viewModelScope.launch { container.settings.setThemeMode(mode) }
    }
}
