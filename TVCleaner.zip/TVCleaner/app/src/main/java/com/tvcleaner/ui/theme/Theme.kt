package com.tvcleaner.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.tvcleaner.core.Risk
import com.tvcleaner.data.ThemeMode

private val DarkColors = darkColorScheme(
    primary = Color(0xFF5CE1B9),
    onPrimary = Color(0xFF00382A),
    primaryContainer = Color(0xFF00513D),
    onPrimaryContainer = Color(0xFF7BF8D4),
    secondary = Color(0xFF9CCBFB),
    onSecondary = Color(0xFF003354),
    secondaryContainer = Color(0xFF1D4A6E),
    onSecondaryContainer = Color(0xFFCFE5FF),
    background = Color(0xFF0F1720),
    onBackground = Color(0xFFE2E8F0),
    surface = Color(0xFF0F1720),
    onSurface = Color(0xFFE2E8F0),
    surfaceVariant = Color(0xFF1B2733),
    onSurfaceVariant = Color(0xFFA7B4C2),
    surfaceContainer = Color(0xFF16212C),
    surfaceContainerHigh = Color(0xFF1B2733),
    outline = Color(0xFF51606F),
    error = Color(0xFFFF8A80),
    onError = Color(0xFF5A0000),
    errorContainer = Color(0xFF5C1F1F),
    onErrorContainer = Color(0xFFFFDAD6),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF006B55),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFF7BF8D4),
    onPrimaryContainer = Color(0xFF002118),
    secondary = Color(0xFF2F628E),
    background = Color(0xFFF7FAFC),
    surface = Color(0xFFF7FAFC),
    surfaceVariant = Color(0xFFE2E8F0),
    onSurfaceVariant = Color(0xFF42505E),
)

/** Colours used for risk badges. */
object RiskColors {
    fun of(risk: Risk, dark: Boolean): Color = when (risk) {
        Risk.SAFE -> if (dark) Color(0xFF66D98A) else Color(0xFF1B7F3B)
        Risk.TEST -> if (dark) Color(0xFFFFC857) else Color(0xFF9A6700)
        Risk.UNKNOWN -> if (dark) Color(0xFF9FB3C8) else Color(0xFF52667A)
        Risk.PROTECTED -> if (dark) Color(0xFFFF8A80) else Color(0xFFB3261E)
    }
}

@Composable
fun isDarkTheme(): Boolean = MaterialTheme.colorScheme.background.red < 0.5f

@Composable
fun TvCleanerTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? android.app.Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
