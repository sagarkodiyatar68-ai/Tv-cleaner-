package com.tvcleaner.ui.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tvcleaner.adb.ConnectionState
import com.tvcleaner.data.db.BatchWithItems
import com.tvcleaner.data.db.ItemStatus
import com.tvcleaner.ui.HistoryViewModel
import com.tvcleaner.ui.components.ApplyProgressDialog
import com.tvcleaner.ui.components.EmptyState
import com.tvcleaner.ui.components.ScreenHeader
import java.text.DateFormat
import java.util.Date

@Composable
fun HistoryScreen(vm: HistoryViewModel) {
    val batches by vm.batches.collectAsStateWithLifecycle()
    val restorable by vm.restorableCount.collectAsStateWithLifecycle()
    val conn by vm.connected.collectAsStateWithLifecycle()
    val progress by vm.runner.state.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<Long?>(null) }
    val connected = conn is ConnectionState.Connected

    Column(modifier = Modifier.fillMaxSize()) {
        ScreenHeader(
            title = "History & Restore",
            subtitle = "Every change is saved here before it is applied.",
            actions = {
                if (batches.isNotEmpty()) {
                    IconButton(onClick = { confirmClear = true }) { Icon(Icons.Default.DeleteSweep, contentDescription = "Clear history") }
                }
            },
        )

        if (batches.isEmpty()) {
            EmptyState(
                icon = Icons.Default.History,
                title = "Nothing changed yet",
                body = "When you disable or remove apps, the restore list appears here so you can undo it.",
            )
        } else {
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("$restorable app${if (restorable == 1) "" else "s"} can be restored", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (connected) "Restores run one app at a time." else "Connect to the TV to restore.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Button(onClick = vm::restoreAll, enabled = restorable > 0 && connected) { Text("Restore all") }
                }
            }
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f),
            ) {
                items(batches, key = { it.batch.id }) { b ->
                    BatchCard(b, connected, onRestore = { vm.restoreBatch(b.batch.id) }, onDelete = { confirmDelete = b.batch.id })
                }
            }
        }
    }

    progress?.let { ApplyProgressDialog(it, onStop = vm.runner::stop, onClose = vm.runner::dismiss) }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear all history?") },
            text = { Text("This deletes the restore list. Apps that are still disabled on the TV stay disabled, and you would have to re-enable them by hand.") },
            confirmButton = { TextButton(onClick = { vm.clearHistory(); confirmClear = false }) { Text("Clear") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
    confirmDelete?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete this entry?") },
            text = { Text("Its restore list is deleted too. Apps it changed stay changed on the TV.") },
            confirmButton = { TextButton(onClick = { vm.deleteBatch(id); confirmDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } },
        )
    }
    message?.let {
        AlertDialog(
            onDismissRequest = vm::dismissMessage,
            confirmButton = { TextButton(onClick = vm::dismissMessage) { Text("OK") } },
            text = { Text(it) },
        )
    }
}

@Composable
private fun BatchCard(b: BatchWithItems, connected: Boolean, onRestore: () -> Unit, onDelete: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }
    val restorableHere = b.items.count { it.status == ItemStatus.APPLIED && (it.action == "DISABLE" || it.action == "REMOVE") }
    val restored = b.items.count { it.status == ItemStatus.RESTORED }

    Card {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    val label = b.batch.action.lowercase().replaceFirstChar { it.uppercase() }.replace('_', ' ')
                    Text("$label • ${b.batch.total} app${if (b.batch.total == 1) "" else "s"}" + if (b.batch.safeMode) " • safe mode" else "", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "${fmt.format(Date(b.batch.createdAt))} • ${b.batch.tvLabel}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                IconButton(onClick = { open = !open }) {
                    Icon(if (open) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = if (open) "Hide apps" else "Show apps")
                }
            }
            Text(
                buildString {
                    append(if (b.batch.finished) "${b.batch.succeeded} ok, ${b.batch.failed} failed" else "Not finished")
                    if (restored > 0) append(", $restored restored")
                },
                style = MaterialTheme.typography.bodySmall,
            )
            if (open) {
                b.items.forEach { item ->
                    Row(verticalAlignment = Alignment.Top) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.label, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(item.pkg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            item.message?.takeIf { it.isNotBlank() && item.status != ItemStatus.APPLIED }?.let {
                                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        Text(item.status.lowercase(), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onRestore, enabled = connected && restorableHere > 0) { Text("Restore ($restorableHere)") }
                TextButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}
