package com.tvcleaner.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tvcleaner.core.Flag
import com.tvcleaner.core.Risk
import com.tvcleaner.domain.AppVisual
import com.tvcleaner.ui.ApplyUiState
import com.tvcleaner.ui.theme.RiskColors
import com.tvcleaner.ui.theme.isDarkTheme

@Composable
fun ScreenHeader(
    title: String,
    subtitle: String? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        actions()
    }
}

@Composable
fun RiskChip(risk: Risk, modifier: Modifier = Modifier) {
    val color = RiskColors.of(risk, isDarkTheme())
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = 0.16f),
        contentColor = color,
    ) {
        Text(
            risk.label.uppercase(),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp,
        )
    }
}

@Composable
fun FlagTag(flag: Flag) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
    ) {
        Text(flag.label, modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp), fontSize = 10.sp)
    }
}

/** Real icon when it has been loaded from the TV, otherwise a coloured letter. */
@Composable
fun AppAvatar(visual: AppVisual?, name: String, risk: Risk, size: Dp = 40.dp) {
    val bitmap = visual?.icon
    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = null,
            modifier = Modifier.size(size).clip(RoundedCornerShape(10.dp)),
        )
    } else {
        val color = RiskColors.of(risk, isDarkTheme())
        Box(
            modifier = Modifier.size(size).clip(CircleShape).background(color.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                name.firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "?",
                color = color,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    body: String,
    actionLabel: String? = null,
    onAction: () -> Unit = {},
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.size(16.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.size(8.dp))
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        if (actionLabel != null) {
            Spacer(Modifier.size(20.dp))
            Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

/** Live progress of a batch with a per-app success/fail list. */
@Composable
fun ApplyProgressDialog(state: ApplyUiState, onStop: () -> Unit, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = { if (state.finished) onClose() },
        title = { Text(state.title) },
        text = {
            Column {
                val fraction = if (state.total == 0) 0f else state.done.toFloat() / state.total
                LinearProgressIndicator(progress = { if (state.finished && state.total == 0) 1f else fraction }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.size(8.dp))
                val status = when {
                    state.stopped -> "Stopped. Remaining apps were not changed."
                    state.aborted -> "Stopped early because of an error."
                    state.finished -> "Finished: ${state.succeeded} ok, ${state.failed} failed."
                    state.current != null -> "Working on ${state.current}... (${state.done + 1} of ${state.total})"
                    else -> "${state.done} of ${state.total} done"
                }
                Text(status, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.size(8.dp))
                LazyColumn(modifier = Modifier.heightIn(max = 280.dp)) {
                    items(state.results.asReversed()) { r ->
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
                            Icon(
                                if (r.success) Icons.Default.CheckCircle else Icons.Default.Error,
                                contentDescription = if (r.success) "Success" else "Failed",
                                modifier = Modifier.size(18.dp),
                                tint = if (r.success) Color(0xFF66D98A) else MaterialTheme.colorScheme.error,
                            )
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(r.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    r.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (state.finished) {
                Button(onClick = onClose) { Text("Done") }
            }
        },
        dismissButton = {
            if (!state.finished) {
                TextButton(onClick = onStop) { Text("Stop") }
            }
        },
    )
}
