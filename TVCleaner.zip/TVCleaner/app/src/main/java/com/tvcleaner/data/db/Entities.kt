package com.tvcleaner.data.db

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

object ItemStatus {
    const val PENDING = "PENDING"
    const val APPLIED = "APPLIED"
    const val FAILED = "FAILED"
    const val SKIPPED = "SKIPPED"
    const val RESTORED = "RESTORED"
}

/** One batch the user applied (also the restore list: written BEFORE any command runs). */
@Entity(tableName = "batches")
data class BatchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long,
    val tvLabel: String,
    val action: String,
    val safeMode: Boolean,
    val total: Int,
    val succeeded: Int = 0,
    val failed: Int = 0,
    val finished: Boolean = false,
)

@Entity(
    tableName = "items",
    foreignKeys = [
        ForeignKey(
            entity = BatchEntity::class,
            parentColumns = ["id"],
            childColumns = ["batchId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("batchId"), Index("pkg")],
)
data class ItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val batchId: Long,
    val pkg: String,
    val label: String,
    val risk: String,
    val action: String,
    val status: String,
    val message: String? = null,
    val updatedAt: Long,
)

data class BatchWithItems(
    @Embedded val batch: BatchEntity,
    @Relation(parentColumn = "id", entityColumn = "batchId") val items: List<ItemEntity>,
)
