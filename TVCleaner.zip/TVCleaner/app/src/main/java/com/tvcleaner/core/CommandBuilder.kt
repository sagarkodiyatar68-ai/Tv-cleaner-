package com.tvcleaner.core

import java.util.Locale

enum class StepKind { DISABLE, ENABLE, UNINSTALL, INSTALL_EXISTING, FORCE_STOP, CLEAR_DATA, CLEAR_CACHE, TRIM_CACHES, SET_SETTING, QUERY }

/** One shell command plus how its output must be interpreted. [required] = false means a failure is tolerated. */
data class ShellStep(val command: String, val kind: StepKind, val required: Boolean = true)

enum class AnimationPreset(val label: String, val scale: Float) {
    FAST("0.3x (fastest)", 0.3f),
    HALF("0.5x (fast)", 0.5f),
    NORMAL("1x (default)", 1.0f),
}

/** Builds every shell command the app runs. Package names are validated to prevent shell injection. */
object CommandBuilder {
    private val PKG_REGEX = Regex("^[A-Za-z_][A-Za-z0-9_]*(\\.[A-Za-z_][A-Za-z0-9_]*)*$")
    private val PATH_REGEX = Regex("^/[A-Za-z0-9_./=+@-]+$")

    const val USER = "--user 0"

    // ---- scanning ----
    const val GETPROP = "getprop"
    const val LIST_SYSTEM = "pm list packages -s"
    const val LIST_THIRD_PARTY = "pm list packages -3"
    const val LIST_DISABLED = "pm list packages -d"
    const val RESOLVE_HOME =
        "cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME"
    const val RESOLVE_HOME_FALLBACK =
        "pm resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME"
    const val QUERY_HOME_CANDIDATES =
        "cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME"
    const val LIST_PROCESSES = "ps -A -o PID,RSS,NAME 2>/dev/null || ps"

    // ---- speed tweaks ----
    const val TRIM_CACHES = "pm trim-caches 999G"
    val ANIMATION_KEYS = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")

    fun isValidPackage(pkg: String): Boolean = PKG_REGEX.matches(pkg)

    fun isValidPath(path: String): Boolean = PATH_REGEX.matches(path)

    private fun checked(pkg: String): String {
        require(isValidPackage(pkg)) { "Invalid package name: $pkg" }
        return pkg
    }

    // ---- actions ----
    fun disable(pkg: String) = "pm disable-user $USER ${checked(pkg)}"
    fun remove(pkg: String) = "pm uninstall -k $USER ${checked(pkg)}"
    fun enable(pkg: String) = "pm enable $USER ${checked(pkg)}"
    fun installExisting(pkg: String) = "cmd package install-existing ${checked(pkg)}"
    fun forceStop(pkg: String) = "am force-stop ${checked(pkg)}"
    fun clearData(pkg: String) = "pm clear ${checked(pkg)}"
    /** Needs Android 12+ on the TV; older TVs answer with an "unknown option" error. */
    fun clearCache(pkg: String) = "pm clear --cache-only ${checked(pkg)}"
    fun packagePath(pkg: String) = "pm path ${checked(pkg)}"

    fun fileSize(path: String): String {
        require(PATH_REGEX.matches(path)) { "Invalid path: $path" }
        return "stat -c %s $path"
    }

    /** Raw file read through the exec: service (no terminal, so no CRLF mangling). */
    fun execCat(path: String): String {
        require(PATH_REGEX.matches(path)) { "Invalid path: $path" }
        return "exec:cat $path"
    }

    fun getAnimationScale(key: String): String {
        require(key in ANIMATION_KEYS) { "Unknown setting: $key" }
        return "settings get global $key"
    }

    fun formatScale(scale: Float): String = String.format(Locale.US, "%.1f", scale)

    fun animationSteps(scale: Float): List<ShellStep> {
        require(scale in 0.0f..10.0f) { "Scale out of range: $scale" }
        val v = formatScale(scale)
        return ANIMATION_KEYS.map { ShellStep("settings put global $it $v", StepKind.SET_SETTING) }
    }

    /** Steps that apply [action] to [pkg]. */
    fun stepsFor(action: CleanAction, pkg: String): List<ShellStep> = when (action) {
        CleanAction.DISABLE -> listOf(ShellStep(disable(pkg), StepKind.DISABLE))
        CleanAction.REMOVE -> listOf(ShellStep(remove(pkg), StepKind.UNINSTALL))
        CleanAction.FORCE_STOP -> listOf(ShellStep(forceStop(pkg), StepKind.FORCE_STOP))
        CleanAction.CLEAR_DATA -> listOf(ShellStep(clearData(pkg), StepKind.CLEAR_DATA))
        CleanAction.CLEAR_CACHE -> listOf(ShellStep(clearCache(pkg), StepKind.CLEAR_CACHE))
    }

    /** Steps that undo a DISABLE or REMOVE. Returns an empty list for actions that can't be undone. */
    fun restoreSteps(action: CleanAction, pkg: String): List<ShellStep> = when (action) {
        CleanAction.DISABLE -> listOf(ShellStep(enable(pkg), StepKind.ENABLE))
        CleanAction.REMOVE -> listOf(
            ShellStep(installExisting(pkg), StepKind.INSTALL_EXISTING),
            ShellStep(enable(pkg), StepKind.ENABLE, required = false),
        )
        else -> emptyList()
    }

    /** Wraps a command so its exit code can be recovered from the plain `shell:` service. */
    fun withExitMarker(command: String): String = "$command; echo \"${ShellParser.EXIT_MARKER}\$?\""
}
