package com.tvcleaner.ui.tweaks

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tvcleaner.adb.ConnectionState
import com.tvcleaner.core.AnimationPreset
import com.tvcleaner.core.CommandBuilder
import com.tvcleaner.domain.BackgroundApp
import com.tvcleaner.ui.TweaksViewModel
import com.tvcleaner.ui.components.ApplyProgressDialog
import com.tvcleaner.ui.components.RiskChip
import com.tvcleaner.ui.components.ScreenHeader

@Composable
fun TweaksScreen(vm: TweaksViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val conn by vm.connection.collectAsStateWithLifecycle()
    val progress by vm.runner.state.collectAsStateWithLifecycle()
    val connected = conn is ConnectionState.Connected
    val busy = ui.busy != null

    LaunchedEffect(connected) {
        if (connected) vm.loadScales()
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenHeader(title = "Speed tweaks", subtitle = if (connected) "Safe, reversible changes that make the TV feel faster." else "Connect to the TV to use these.")

        ui.busy?.let {
            Row(modifier = Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(Modifier.size(10.dp))
                Text(it, style = MaterialTheme.typography.bodyMedium)
            }
        }

        SectionCard("Trim caches", "Frees cache space on the TV (${CommandBuilder.TRIM_CACHES}). Apps rebuild their caches when needed.") {
            Button(onClick = vm::trimCaches, enabled = connected && !busy) { Text("Trim caches") }
            ui.trimResult?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }

        SectionCard("Animation speed", "Shorter window, transition and animator scales make menus feel snappier.") {
            val s = ui.scales
            if (s != null) {
                Text(
                    "Now: window ${fmt(s.window)} • transition ${fmt(s.transition)} • animator ${fmt(s.animator)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AnimationPreset.values().forEach { p ->
                    FilledTonalButton(onClick = { vm.setScale(p.scale) }, enabled = connected && !busy) {
                        Text(p.label.substringBefore(' '))
                    }
                }
            }
            Text("0.3x fastest • 0.5x fast • 1x is Android's default", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            ui.animResult?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }

        SectionCard("Background apps", "Lists running app processes. Protected system apps can't be stopped.") {
            OutlinedButton(onClick = vm::loadBackground, enabled = connected && !busy) {
                Text(if (ui.backgroundLoaded) "Refresh list" else "List background apps")
            }
            if (ui.backgroundLoaded && ui.background.isEmpty()) {
                Text("No app processes found.", style = MaterialTheme.typography.bodySmall)
            }
            ui.background.forEach { app ->
                BackgroundRow(app, selected = app.pkg in ui.selected, onToggle = { vm.toggle(app.pkg) })
            }
            if (ui.background.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = vm::stopSelected, enabled = connected && ui.selected.isNotEmpty()) { Text("Stop selected (${ui.selected.size})") }
                    OutlinedButton(onClick = vm::stopAll, enabled = connected) { Text("Stop all") }
                }
            }
        }

        SectionCard("Display & storage", "Names and icons are read from the TV's APK files on demand and cached on this phone.") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Load app names and icons", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                Switch(checked = ui.loadIcons, onCheckedChange = vm::setLoadIcons)
            }
            TextButton(onClick = vm::clearIconCache) { Text("Clear icon cache") }
        }
    }

    progress?.let { ApplyProgressDialog(it, onStop = vm.runner::stop, onClose = vm.runner::dismiss) }
    ui.message?.let {
        AlertDialog(
            onDismissRequest = vm::dismissMessage,
            confirmButton = { TextButton(onClick = vm::dismissMessage) { Text("OK") } },
            text = { Text(it) },
        )
    }
}

private fun fmt(v: Float?): String = if (v == null) "1.0 (default)" else CommandBuilder.formatScale(v)

@Composable
private fun SectionCard(title: String, subtitle: String, content: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}

@Composable
private fun BackgroundRow(app: BackgroundApp, selected: Boolean, onToggle: () -> Unit) {
    val enabled = app.classification.selectable
    Row(
        modifier = Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onToggle),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (enabled) {
            Checkbox(checked = selected, onCheckedChange = null)
        } else {
            Icon(Icons.Default.Lock, contentDescription = "Protected", modifier = Modifier.padding(12.dp).size(18.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(app.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                app.pkg + (app.rssKb?.let { " • ${it / 1024} MB" } ?: ""),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        RiskChip(app.classification.risk)
    }
}
