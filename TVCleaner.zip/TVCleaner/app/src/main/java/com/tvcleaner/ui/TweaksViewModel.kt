package com.tvcleaner.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tvcleaner.AppContainer
import com.tvcleaner.adb.AdbFailure
import com.tvcleaner.core.CleanAction
import com.tvcleaner.domain.AnimationScales
import com.tvcleaner.domain.BackgroundApp
import com.tvcleaner.domain.ApplyTarget
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TweaksUiState(
    val busy: String? = null,
    val trimResult: String? = null,
    val scales: AnimationScales? = null,
    val animResult: String? = null,
    val background: List<BackgroundApp> = emptyList(),
    val backgroundLoaded: Boolean = false,
    val selected: Set<String> = emptySet(),
    val loadIcons: Boolean = true,
    val message: String? = null,
)

class TweaksViewModel(private val container: AppContainer) : ViewModel() {
    private val repo get() = container.repository
    private val session = container.session

    private val _ui = MutableStateFlow(TweaksUiState())
    val ui: StateFlow<TweaksUiState> = _ui.asStateFlow()
    val connection = session.state
    val runner = ApplyRunner(viewModelScope)

    init {
        viewModelScope.launch {
            container.settings.loadIcons.collect { v -> _ui.update { it.copy(loadIcons = v) } }
        }
    }

    private fun connected(): Boolean {
        if (session.isConnected) return true
        _ui.update { it.copy(message = "Connect to the TV first (Connect tab).") }
        return false
    }

    private fun <T> guarded(label: String, block: suspend () -> T, onOk: (T) -> Unit) {
        if (!connected()) return
        viewModelScope.launch {
            _ui.update { it.copy(busy = label, message = null) }
            try {
                val value = block()
                onOk(value)
            } catch (e: AdbFailure) {
                _ui.update { it.copy(message = e.userMessage) }
            } catch (e: Exception) {
                _ui.update { it.copy(message = e.message ?: "Something went wrong.") }
            } finally {
                _ui.update { it.copy(busy = null) }
            }
        }
    }

    fun dismissMessage() = _ui.update { it.copy(message = null) }

    // ---- caches ----
    fun trimCaches() = guarded("Trimming caches...", { repo.trimCaches() }) { o ->
        _ui.update { it.copy(trimResult = if (o.success) "Done. Cache trim finished." else "Failed: ${o.message}") }
    }

    // ---- animations ----
    fun loadScales() = guarded("Reading animation scales...", { repo.readAnimationScales() }) { s ->
        _ui.update { it.copy(scales = s) }
    }

    fun setScale(scale: Float) = guarded("Setting animations...", { repo.setAnimationScale(scale) }) { o ->
        _ui.update { it.copy(animResult = if (o.success) o.message else "Failed: ${o.message}") }
        loadScales()
    }

    // ---- background apps ----
    fun loadBackground() = guarded("Listing background apps...", { repo.backgroundApps() }) { list ->
        _ui.update { it.copy(background = list, backgroundLoaded = true, selected = emptySet()) }
    }

    fun toggle(pkg: String) = _ui.update { s ->
        val app = s.background.firstOrNull { it.pkg == pkg }
        if (app == null || !app.classification.selectable) s
        else s.copy(selected = if (pkg in s.selected) s.selected - pkg else s.selected + pkg)
    }

    fun stopSelected() = stop(_ui.value.background.filter { it.pkg in _ui.value.selected })

    fun stopAll() = stop(_ui.value.background.filter { it.classification.selectable })

    private fun stop(apps: List<BackgroundApp>) {
        if (!connected()) return
        if (apps.isEmpty()) {
            _ui.update { it.copy(message = "No apps to stop.") }
            return
        }
        val targets = apps.map { ApplyTarget(it.pkg, it.name, it.classification) }
        runner.run("Force stop (${targets.size})", repo.apply(CleanAction.FORCE_STOP, targets, safeMode = false)) {
            if (session.isConnected) loadBackground()
        }
    }

    // ---- display ----
    fun setLoadIcons(enabled: Boolean) {
        viewModelScope.launch { container.settings.setLoadIcons(enabled) }
    }

    fun clearIconCache() {
        container.icons.clearCache()
        _ui.update { it.copy(message = "Icon cache cleared.") }
    }
}
