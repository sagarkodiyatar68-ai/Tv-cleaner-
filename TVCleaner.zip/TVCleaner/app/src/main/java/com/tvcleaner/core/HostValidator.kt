package com.tvcleaner.core

/**
 * The app only talks to devices on the local network. Public internet addresses are rejected before any
 * socket is opened, so a typo can never send ADB traffic to a server out on the internet.
 */
object HostValidator {
    const val LOCAL_ONLY_MESSAGE =
        "For safety this app only connects to devices on your local network: use the TV's private IP " +
            "address (for example 192.168.1.50 or 10.0.0.20)."

    /** Returns an error message, or null when [host] is an acceptable local address. */
    fun validate(host: String): String? {
        val h = host.trim()
        if (h.isEmpty()) return "Enter the TV's IP address, for example 192.168.1.50."
        return if (isLocalAddress(h)) null else LOCAL_ONLY_MESSAGE
    }

    fun isLocalAddress(host: String): Boolean {
        val h = host.trim().lowercase().substringBefore('%') // drop an IPv6 zone id
        if (h.isEmpty()) return false
        parseIpv4(h)?.let { (a, b) ->
            return a == 10 ||                    // 10.0.0.0/8
                (a == 172 && b in 16..31) ||     // 172.16.0.0/12
                (a == 192 && b == 168) ||        // 192.168.0.0/16
                (a == 169 && b == 254) ||        // link-local
                (a == 100 && b in 64..127) ||    // carrier-grade NAT / Tailscale
                a == 127                         // loopback
        }
        if (':' in h) {
            if (h == "::1") return true
            val first = h.substringBefore(':').padStart(4, '0').toIntOrNull(16) ?: return false
            return first in 0xFC00..0xFDFF ||    // unique local fc00::/7
                first in 0xFE80..0xFEBF          // link-local fe80::/10
        }
        return h.endsWith(".local") && h.length > ".local".length &&
            h.all { it.isLetterOrDigit() || it == '.' || it == '-' }
    }

    private fun parseIpv4(h: String): List<Int>? {
        val parts = h.split('.')
        if (parts.size != 4) return null
        val nums = parts.map { p -> p.takeIf { it.isNotEmpty() && it.length <= 3 && it.all(Char::isDigit) }?.toIntOrNull() }
        if (nums.any { it == null || it !in 0..255 }) return null
        return nums.map { it!! }
    }
}
