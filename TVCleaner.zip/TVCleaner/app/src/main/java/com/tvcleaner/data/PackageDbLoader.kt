package com.tvcleaner.data

import android.content.Context
import com.tvcleaner.core.PackageDb
import com.tvcleaner.core.PackageDbParser

object PackageDbLoader {
    private const val ASSET = "package_db.json"

    fun load(context: Context): PackageDb {
        val text = context.assets.open(ASSET).bufferedReader(Charsets.UTF_8).use { it.readText() }
        return PackageDbParser.parse(text)
    }
}
