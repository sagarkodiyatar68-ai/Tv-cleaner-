package com.tvcleaner.adb

/** Every ADB problem the UI needs to explain, with a ready-to-show message. */
sealed class AdbFailure(val userMessage: String, cause: Throwable? = null) : Exception(userMessage, cause) {

    class Unreachable(val host: String, val port: Int, cause: Throwable? = null) : AdbFailure(
        "Can't reach $host:$port. Check the IP and port, that the TV is on, that debugging is enabled " +
            "on the TV, and that the phone is on the same network.",
        cause,
    )

    class AuthRefused(cause: Throwable? = null) : AdbFailure(
        "The TV refused this phone. Accept the \"Allow USB debugging?\" prompt on the TV and tick " +
            "\"Always allow\". If you tapped Deny earlier, revoke USB debugging authorizations in the TV's " +
            "developer options and try again.",
        cause,
    )

    class AuthTimeout : AdbFailure(
        "The TV didn't confirm in time. Look for the \"Allow USB debugging?\" prompt on the TV screen, " +
            "accept it, then connect again.",
    )

    class PairingRequired(cause: Throwable? = null) : AdbFailure(
        "This TV needs pairing first (Android 11+ wireless debugging). On the TV open Developer options > " +
            "Wireless debugging > Pair device with pairing code, then enter the pairing port and 6-digit code here.",
        cause,
    )

    class PairingFailed(cause: Throwable? = null) : AdbFailure(
        "Pairing failed. The pairing code and port expire quickly: reopen the pairing dialog on the TV " +
            "and use the new code and port.",
        cause,
    )

    class Disconnected(cause: Throwable? = null) : AdbFailure(
        "The connection to the TV was lost. Reconnect from the Connect tab.",
        cause,
    )

    class CommandTimeout(val command: String) : AdbFailure("The TV didn't answer in time.")

    class Failed(message: String, cause: Throwable? = null) : AdbFailure(message, cause)
}
