package com.tvcleaner.adb

import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import java.security.PrivateKey
import java.security.cert.Certificate

/** The phone's ADB identity: RSA private key plus a self-signed certificate that wraps the public key. */
class AdbCredentials(val privateKey: PrivateKey, val certificate: Certificate)

/** libadb-android connection manager backed by our stored [AdbCredentials]. */
class TvAdbConnectionManager(private val credentials: AdbCredentials) : AbsAdbConnectionManager() {
    init {
        setApi(Build.VERSION.SDK_INT)
    }

    override fun getPrivateKey(): PrivateKey = credentials.privateKey

    override fun getCertificate(): Certificate = credentials.certificate

    override fun getDeviceName(): String = "TV Cleaner"
}
