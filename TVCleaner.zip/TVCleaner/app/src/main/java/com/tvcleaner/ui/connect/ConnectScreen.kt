package com.tvcleaner.ui.connect

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tvcleaner.adb.ConnectionState
import com.tvcleaner.data.ThemeMode
import com.tvcleaner.ui.ConnectViewModel
import com.tvcleaner.ui.components.ScreenHeader

@Composable
fun ConnectScreen(vm: ConnectViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val conn by vm.connection.collectAsStateWithLifecycle()
    var pairingOpen by rememberSaveable { mutableStateOf(false) }
    var guideOpen by rememberSaveable { mutableStateOf(true) }
    var themeMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth().imePadding().verticalScroll(rememberScrollState()).padding(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenHeader(
            title = "Connect",
            subtitle = "Connect to your Android TV over the local network with ADB.",
            actions = {
                IconButton(onClick = { themeMenu = true }) { Icon(Icons.Default.DarkMode, contentDescription = "Theme") }
                DropdownMenu(expanded = themeMenu, onDismissRequest = { themeMenu = false }) {
                    ThemeMode.values().forEach { mode ->
                        DropdownMenuItem(
                            text = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) },
                            onClick = { vm.setTheme(mode); themeMenu = false },
                        )
                    }
                }
            },
        )

        StatusCard(conn, onDisconnect = vm::disconnect)

        Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = ui.host,
                    onValueChange = vm::onHost,
                    label = { Text("TV IP address") },
                    placeholder = { Text("192.168.1.50") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.weight(1f),
                    enabled = !ui.busy,
                )
                OutlinedTextField(
                    value = ui.port,
                    onValueChange = vm::onPort,
                    label = { Text("Port") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(0.5f),
                    enabled = !ui.busy,
                )
            }

            TextButton(onClick = { pairingOpen = !pairingOpen }) {
                Text("Android 11+ wireless debugging: pairing (optional)")
                Spacer(Modifier.size(4.dp))
                Icon(if (pairingOpen) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
            }
            if (pairingOpen) {
                Text(
                    "Only needed once per phone. On the TV: Developer options > Wireless debugging > Pair device with pairing code. " +
                        "Enter the pairing port and code shown there, and put the main Wireless debugging port in the Port field above.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = ui.pairPort,
                        onValueChange = vm::onPairPort,
                        label = { Text("Pairing port") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        enabled = !ui.busy,
                    )
                    OutlinedTextField(
                        value = ui.pairCode,
                        onValueChange = vm::onPairCode,
                        label = { Text("6-digit code") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.weight(1f),
                        enabled = !ui.busy,
                    )
                }
            }

            Button(onClick = vm::connect, enabled = !ui.busy, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                if (ui.busy) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.size(10.dp))
                    Text("Connecting...")
                } else {
                    Text(if (ui.pairCode.isNotEmpty()) "Pair and connect" else "Connect")
                }
            }

            val step = (conn as? ConnectionState.Connecting)?.step
            if (ui.busy && step != null) {
                Text(step, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            ui.error?.let { ErrorCard(it) }
        }

        GuideCard(open = guideOpen, onToggle = { guideOpen = !guideOpen })

        Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "This phone's ADB key" + if (ui.keyFingerprint.isNotEmpty()) ": ${ui.keyFingerprint}" else "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "The key is created on this phone, encrypted with the Android Keystore and never leaves it.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedButton(onClick = vm::resetKey, enabled = !ui.busy) { Text("Forget this phone's key") }
        }
    }
}

@Composable
private fun StatusCard(conn: ConnectionState, onDisconnect: () -> Unit) {
    val text = when (conn) {
        is ConnectionState.Connected -> "Connected to ${conn.host}:${conn.port}"
        is ConnectionState.Connecting -> "Connecting..."
        is ConnectionState.Disconnected -> conn.reason ?: "Not connected"
    }
    val connected = conn is ConnectionState.Connected
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (connected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        ),
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
            if (connected) TextButton(onClick = onDisconnect) { Text("Disconnect") }
        }
    }
}

@Composable
private fun ErrorCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
        Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
            Text(message, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun GuideCard(open: Boolean, onToggle: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Enable debugging on the TV", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = onToggle) {
                    Icon(if (open) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = if (open) "Collapse" else "Expand")
                }
            }
            if (open) {
                GUIDE_STEPS.forEachIndexed { i, step ->
                    Text("${i + 1}. $step", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

private val GUIDE_STEPS = listOf(
    "Put the phone and the TV on the same Wi-Fi or LAN (not a guest network).",
    "On the TV open Settings > System > About and press OK on \"Build\" (or \"Android TV OS build\") 7 times. Developer options is now unlocked.",
    "Open Settings > System > Developer options and turn on USB debugging. On many TVs this also opens network ADB on port 5555. If you see \"Network debugging\" or \"ADB over network\", turn that on too.",
    "Android 11+ / Google TV: turn on Wireless debugging instead. The TV shows its IP address and a port (random, changes each time). Enter both above. Then tap \"Pair device with pairing code\" and use the pairing section above.",
    "Find the TV's IP in Settings > Network & Internet > your network > IP address.",
    "Tap Connect. The TV shows \"Allow USB debugging?\". Tick \"Always allow\" and choose OK.",
    "If connecting fails: toggle USB debugging off and on, or use \"Revoke USB debugging authorizations\" in Developer options, then try again.",
)
