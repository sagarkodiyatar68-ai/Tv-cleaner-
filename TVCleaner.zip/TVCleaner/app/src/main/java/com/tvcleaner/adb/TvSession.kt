package com.tvcleaner.adb

import com.tvcleaner.core.CommandBuilder
import com.tvcleaner.core.ShellParser
import com.tvcleaner.data.CredentialStore
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import io.github.muntashirakon.adb.AdbAuthenticationFailedException
import io.github.muntashirakon.adb.AdbPairingRequiredException
import io.github.muntashirakon.adb.AdbStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

data class ShellResult(val output: String, val exitCode: Int?)

/** The part of the ADB session the repository needs. Faked in unit tests. */
interface AdbShell {
    /** Runs a shell command on the TV. Throws [AdbFailure]. */
    suspend fun shell(command: String, timeoutMs: Long = 30_000L): ShellResult
}

sealed interface ConnectionState {
    data class Disconnected(val reason: String? = null) : ConnectionState
    data class Connecting(val step: String) : ConnectionState
    data class Connected(val host: String, val port: Int) : ConnectionState
}

/**
 * Owns the single ADB connection to the TV.
 * Commands run one at a time (mutex); file pulls use their own stream and may overlap with commands.
 */
class TvSession(private val credentials: CredentialStore) : AdbShell {
    private val _state = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected())
    val state: StateFlow<ConnectionState> = _state.asStateFlow()

    val isConnected: Boolean get() = _state.value is ConnectionState.Connected

    @Volatile
    private var manager: AbsAdbConnectionManager? = null
    private val shellMutex = Mutex()
    private val watchdog = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "adb-watchdog").apply { isDaemon = true }
    }

    // ------------------------------------------------------------------ pairing

    /** Android 11+ wireless debugging: pair with the 6-digit code shown on the TV. */
    suspend fun pair(host: String, pairPort: Int, code: String) {
        _state.value = ConnectionState.Connecting("Pairing with $host:$pairPort...")
        try {
            probe(host, pairPort)
            val creds = withContext(Dispatchers.IO) { credentials.loadOrCreate() }
            val finished = withTimeoutOrNull(PAIR_TIMEOUT_MS) {
                runInterruptible(Dispatchers.IO) {
                    try {
                        TvAdbConnectionManager(creds).pair(host, pairPort, code)
                    } catch (e: Exception) {
                        throw AdbFailure.PairingFailed(e)
                    }
                }
            }
            if (finished != true) throw AdbFailure.PairingFailed()
            _state.value = ConnectionState.Disconnected()
        } catch (e: AdbFailure) {
            _state.value = ConnectionState.Disconnected(e.userMessage)
            throw e
        }
    }

    // ------------------------------------------------------------------ connect / disconnect

    /** Connects to [host]:[port]. Works for classic adb-over-TCP (5555) and wireless-debugging (TLS) ports. */
    suspend fun connect(host: String, port: Int) {
        disconnect()
        _state.value = ConnectionState.Connecting("Reaching $host:$port...")
        try {
            probe(host, port)
            _state.value = ConnectionState.Connecting("Authorizing. Accept the prompt on the TV if it appears...")
            withContext(Dispatchers.IO) {
                val m = TvAdbConnectionManager(credentials.loadOrCreate())
                m.setTimeout(AUTH_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                val ok = try {
                    m.connect(host, port)
                } catch (e: AdbPairingRequiredException) {
                    throw AdbFailure.PairingRequired(e)
                } catch (e: AdbAuthenticationFailedException) {
                    throw AdbFailure.AuthRefused(e)
                } catch (e: InterruptedException) {
                    throw AdbFailure.AuthTimeout()
                } catch (e: IOException) {
                    // libadb reports a refused or denied authorization as a plain "Connection failed".
                    if (e.message == "Connection failed") throw AdbFailure.AuthRefused(e)
                    throw AdbFailure.Failed("Connection error: ${e.message ?: e.javaClass.simpleName}", e)
                } catch (e: AdbFailure) {
                    throw e
                } catch (e: Exception) {
                    throw AdbFailure.Failed("Connection error: ${e.message ?: e.javaClass.simpleName}", e)
                }
                if (!ok || !m.isConnected) {
                    try { m.disconnect() } catch (_: IOException) { }
                    throw AdbFailure.AuthTimeout()
                }
                manager = m
                val hello = shellBlocking("echo tvcleaner_ok", 10_000)
                if ("tvcleaner_ok" !in hello.output) {
                    dropConnection(null)
                    throw AdbFailure.Failed("Connected, but the TV's shell didn't answer. Try again.")
                }
            }
            _state.value = ConnectionState.Connected(host, port)
        } catch (e: AdbFailure) {
            dropConnection(e.userMessage)
            throw e
        }
    }

    fun disconnect() {
        dropConnection(null)
    }

    private fun dropConnection(reason: String?) {
        val m = manager
        manager = null
        if (m != null) {
            try { m.disconnect() } catch (_: Exception) { }
        }
        _state.value = ConnectionState.Disconnected(reason)
    }

    private suspend fun probe(host: String, port: Int) {
        withContext(Dispatchers.IO) {
            try {
                Socket().use { it.connect(InetSocketAddress(host, port), PROBE_TIMEOUT_MS) }
            } catch (e: IOException) {
                throw AdbFailure.Unreachable(host, port, e)
            } catch (e: SecurityException) {
                throw AdbFailure.Unreachable(host, port, e)
            }
        }
    }

    // ------------------------------------------------------------------ commands

    override suspend fun shell(command: String, timeoutMs: Long): ShellResult =
        shellMutex.withLock { withContext(Dispatchers.IO) { shellBlocking(command, timeoutMs) } }

    private fun shellBlocking(command: String, timeoutMs: Long): ShellResult {
        val m = manager ?: throw AdbFailure.Disconnected()
        val stream = try {
            m.openStream("shell:" + CommandBuilder.withExitMarker(command))
        } catch (e: IOException) {
            throw lost(e)
        } catch (e: InterruptedException) {
            throw lost(e)
        }
        val timedOut = AtomicBoolean(false)
        val guard = watchdog.schedule({
            timedOut.set(true)
            try { stream.close() } catch (_: Exception) { }
        }, timeoutMs, TimeUnit.MILLISECONDS)
        val bytes = ByteArrayOutputStream()
        try {
            readAll(stream) { buf, n ->
                bytes.write(buf, 0, n)
                bytes.size() < MAX_SHELL_OUTPUT
            }
        } catch (e: IOException) {
            if (!timedOut.get()) throw lost(e)
        } finally {
            guard.cancel(false)
            try { stream.close() } catch (_: Exception) { }
        }
        if (timedOut.get()) throw AdbFailure.CommandTimeout(command)
        val (out, code) = ShellParser.splitExit(String(bytes.toByteArray(), Charsets.UTF_8))
        return ShellResult(out, code)
    }

    /** Copies a file from the TV into [out] using the raw `exec:` service. Returns the byte count. */
    suspend fun pullFile(path: String, maxBytes: Long, out: OutputStream): Long = withContext(Dispatchers.IO) {
        val m = manager ?: throw AdbFailure.Disconnected()
        val stream = try {
            m.openStream(CommandBuilder.execCat(path))
        } catch (e: IOException) {
            throw lost(e)
        } catch (e: InterruptedException) {
            throw lost(e)
        }
        val timedOut = AtomicBoolean(false)
        val guard = watchdog.schedule({
            timedOut.set(true)
            try { stream.close() } catch (_: Exception) { }
        }, PULL_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        var total = 0L
        var tooLarge = false
        try {
            readAll(stream) { buf, n ->
                total += n
                if (total > maxBytes) {
                    tooLarge = true
                    false
                } else {
                    out.write(buf, 0, n)
                    true
                }
            }
        } catch (e: IOException) {
            if (!timedOut.get()) throw lost(e)
        } finally {
            guard.cancel(false)
            try { stream.close() } catch (_: Exception) { }
        }
        if (timedOut.get()) throw AdbFailure.CommandTimeout("pull $path")
        if (tooLarge) throw AdbFailure.Failed("File is larger than ${maxBytes / 1_000_000} MB.")
        total
    }

    private inline fun readAll(stream: AdbStream, onChunk: (ByteArray, Int) -> Boolean) {
        val input = stream.openInputStream()
        val buf = ByteArray(16 * 1024)
        while (true) {
            // Never use single-byte read(): libadb returns signed values from it.
            val n = try {
                input.read(buf, 0, buf.size)
            } catch (e: IOException) {
                if (stream.isClosed) -1 else throw e
            }
            if (n <= 0) return
            if (!onChunk(buf, n)) return
        }
    }

    private fun lost(e: Exception): AdbFailure {
        val m = manager
        if (m == null || !m.isConnected) {
            dropConnection("Connection lost.")
            return AdbFailure.Disconnected(e)
        }
        return AdbFailure.Failed("ADB error: ${e.message ?: e.javaClass.simpleName}", e)
    }

    companion object {
        private const val PROBE_TIMEOUT_MS = 5_000
        private const val AUTH_TIMEOUT_SECONDS = 60L
        private const val PAIR_TIMEOUT_MS = 30_000L
        private const val PULL_TIMEOUT_MS = 120_000L
        private const val MAX_SHELL_OUTPUT = 8 * 1024 * 1024
    }
}
