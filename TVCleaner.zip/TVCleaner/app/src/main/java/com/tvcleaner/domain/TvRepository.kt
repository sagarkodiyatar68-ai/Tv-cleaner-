package com.tvcleaner.domain

import com.tvcleaner.adb.AdbFailure
import com.tvcleaner.adb.AdbShell
import com.tvcleaner.core.Classification
import com.tvcleaner.core.Classifier
import com.tvcleaner.core.CleanAction
import com.tvcleaner.core.CommandBuilder
import com.tvcleaner.core.Outcome
import com.tvcleaner.core.PackageDb
import com.tvcleaner.core.ProcessInfo
import com.tvcleaner.core.Risk
import com.tvcleaner.core.ScannedApp
import com.tvcleaner.core.ShellParser
import com.tvcleaner.core.ShellStep
import com.tvcleaner.core.TvInfo
import com.tvcleaner.data.db.BatchEntity
import com.tvcleaner.data.db.ItemEntity
import com.tvcleaner.data.db.ItemStatus
import com.tvcleaner.data.db.RestoreDao
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext

/** Something the user can act on: an installed app plus how it was classified. */
data class ApplyTarget(val pkg: String, val name: String, val classification: Classification)

fun ScannedApp.toTarget() = ApplyTarget(pkg, name, classification)

data class ApplyItemResult(val pkg: String, val name: String, val success: Boolean, val message: String)

sealed interface ApplyEvent {
    data class Started(val batchId: Long, val total: Int) : ApplyEvent
    data class Progress(val index: Int, val total: Int, val pkg: String, val name: String) : ApplyEvent
    data class ItemDone(val index: Int, val total: Int, val result: ApplyItemResult) : ApplyEvent
    data class Finished(val succeeded: Int, val failed: Int, val aborted: Boolean) : ApplyEvent
}

data class ScanResult(
    val tv: TvInfo,
    val launcher: String?,
    val apps: List<ScannedApp>,
)

data class BackgroundApp(val pkg: String, val name: String, val rssKb: Long?, val classification: Classification)

data class AnimationScales(val window: Float?, val transition: Float?, val animator: Float?)

class TvRepository(
    private val adb: AdbShell,
    private val dao: RestoreDao,
    private val db: PackageDb,
) {
    @Volatile
    private var classifier: Classifier = Classifier(db)

    @Volatile
    var tv: TvInfo? = null
        private set

    @Volatile
    var launcher: String? = null
        private set

    // ------------------------------------------------------------------ scan

    suspend fun scan(onStep: (String) -> Unit = {}): ScanResult {
        onStep("Reading TV details...")
        val props = ShellParser.parseGetprop(adb.shell(CommandBuilder.GETPROP).output)
        val info = ShellParser.parseTvInfo(props)

        onStep("Listing system apps...")
        val system = ShellParser.parsePackages(adb.shell(CommandBuilder.LIST_SYSTEM).output)
        onStep("Listing installed apps...")
        val third = ShellParser.parsePackages(adb.shell(CommandBuilder.LIST_THIRD_PARTY).output)
        onStep("Listing disabled apps...")
        val disabled = ShellParser.parsePackages(adb.shell(CommandBuilder.LIST_DISABLED).output)
        if (system.isEmpty() && third.isEmpty()) {
            throw AdbFailure.Failed("The TV returned no package list. Try again, or reconnect.")
        }

        onStep("Finding the home launcher...")
        val (home, protectedMap) = resolveLauncher()
        val clf = Classifier(db).withDynamicProtection(protectedMap)
        classifier = clf
        tv = info
        launcher = home

        val apps = (system + third).map { pkg ->
            val c = clf.classify(pkg)
            ScannedApp(
                pkg = pkg,
                name = c.name,
                isSystem = pkg in system,
                isThirdParty = pkg in third,
                isDisabled = pkg in disabled,
                classification = c,
            )
        }
        return ScanResult(info, home, apps)
    }

    /** The active launcher is always protected. If it can't be determined, every HOME-capable app is. */
    private suspend fun resolveLauncher(): Pair<String?, Map<String, String>> {
        var home = ShellParser.parseHomePackage(shellOrEmpty(CommandBuilder.RESOLVE_HOME))
        if (home == null) home = ShellParser.parseHomePackage(shellOrEmpty(CommandBuilder.RESOLVE_HOME_FALLBACK))
        if (home != null) return home to mapOf(home to "Active home launcher. Disabling it would break the Home button.")
        val candidates = ShellParser.parseHomeCandidates(shellOrEmpty(CommandBuilder.QUERY_HOME_CANDIDATES))
        return null to candidates.associateWith { "Possible home launcher (the active one couldn't be determined)." }
    }

    private suspend fun shellOrEmpty(command: String): String = try {
        adb.shell(command).output
    } catch (e: AdbFailure) {
        if (e is AdbFailure.Disconnected) throw e
        ""
    }

    // ------------------------------------------------------------------ apply

    /**
     * Applies [action] to [targets] one app at a time. For DISABLE/REMOVE the restore list is saved first.
     * PROTECTED apps are always skipped; with [safeMode] only SAFE apps run.
     */
    fun apply(action: CleanAction, targets: List<ApplyTarget>, safeMode: Boolean): Flow<ApplyEvent> = flow {
        val eligible = targets.filter { it.classification.selectable && (!safeMode || it.classification.risk == Risk.SAFE) }
        val record = action.restorable
        val liveProtection = if (action == CleanAction.DISABLE || action == CleanAction.REMOVE || action == CleanAction.CLEAR_DATA) {
            resolveLauncher().second.keys
        } else {
            emptySet()
        }

        var batchId = 0L
        var itemIds: List<Long> = emptyList()
        if (record) {
            val now = System.currentTimeMillis()
            batchId = dao.insertBatch(
                BatchEntity(
                    createdAt = now,
                    tvLabel = tvLabel(),
                    action = action.name,
                    safeMode = safeMode,
                    total = eligible.size,
                ),
            )
            itemIds = dao.insertItems(
                eligible.map {
                    ItemEntity(
                        batchId = batchId,
                        pkg = it.pkg,
                        label = it.name,
                        risk = it.classification.risk.name,
                        action = action.name,
                        status = ItemStatus.PENDING,
                        updatedAt = now,
                    )
                },
            )
        }

        emit(ApplyEvent.Started(batchId, eligible.size))
        var ok = 0
        var failed = 0
        var aborted = false
        var current = -1
        try {
            for ((i, target) in eligible.withIndex()) {
                currentCoroutineContext().ensureActive()
                current = i
                emit(ApplyEvent.Progress(i, eligible.size, target.pkg, target.name))
                val outcome = if (target.pkg in liveProtection) {
                    Outcome(false, "Skipped: this is the active home launcher.")
                } else {
                    runSteps(CommandBuilder.stepsFor(action, target.pkg))
                }
                if (outcome.success) ok++ else failed++
                if (record) {
                    dao.setItemStatus(
                        itemIds[i],
                        if (outcome.success) ItemStatus.APPLIED else ItemStatus.FAILED,
                        outcome.message,
                        System.currentTimeMillis(),
                    )
                }
                current = -1
                emit(ApplyEvent.ItemDone(i, eligible.size, ApplyItemResult(target.pkg, target.name, outcome.success, outcome.message)))
            }
        } catch (e: AdbFailure) {
            aborted = true
            if (current >= 0) {
                failed++
                val t = eligible[current]
                if (record) dao.setItemStatus(itemIds[current], ItemStatus.FAILED, e.userMessage, System.currentTimeMillis())
                emit(ApplyEvent.ItemDone(current, eligible.size, ApplyItemResult(t.pkg, t.name, false, e.userMessage)))
            }
        } finally {
            if (record) {
                withContext(NonCancellable) {
                    dao.bulkStatus(batchId, ItemStatus.PENDING, ItemStatus.SKIPPED, System.currentTimeMillis())
                    dao.finishBatch(batchId, ok, failed)
                }
            }
        }
        emit(ApplyEvent.Finished(ok, failed, aborted))
    }

    // ------------------------------------------------------------------ restore

    private data class RestoreGroup(val pkg: String, val name: String, val action: CleanAction, val itemIds: List<Long>)

    private fun groupsFrom(items: List<ItemEntity>): List<RestoreGroup> =
        items.groupBy { it.pkg }.map { (pkg, rows) ->
            val action = if (rows.any { it.action == CleanAction.REMOVE.name }) CleanAction.REMOVE else CleanAction.DISABLE
            RestoreGroup(pkg, rows.first().label, action, rows.map { it.id })
        }

    fun restoreAll(): Flow<ApplyEvent> = flow {
        emitAll(runRestore(groupsFrom(dao.appliedRestorable())))
    }

    fun restoreBatch(batchId: Long): Flow<ApplyEvent> = flow {
        emitAll(runRestore(groupsFrom(dao.appliedInBatch(batchId))))
    }

    /** Re-enables apps that are currently disabled on the TV (also marks matching history rows as restored). */
    fun restoreApps(targets: List<ApplyTarget>): Flow<ApplyEvent> = flow {
        val groups = targets.map { t ->
            val rows = dao.appliedForPackage(t.pkg)
            val action = if (rows.any { it.action == CleanAction.REMOVE.name }) CleanAction.REMOVE else CleanAction.DISABLE
            RestoreGroup(t.pkg, t.name, action, rows.map { it.id })
        }
        emitAll(runRestore(groups))
    }

    private fun runRestore(groups: List<RestoreGroup>): Flow<ApplyEvent> = flow {
        emit(ApplyEvent.Started(0L, groups.size))
        var ok = 0
        var failed = 0
        var aborted = false
        run {
            for ((i, g) in groups.withIndex()) {
                currentCoroutineContext().ensureActive()
                emit(ApplyEvent.Progress(i, groups.size, g.pkg, g.name))
                val outcome = try {
                    runSteps(CommandBuilder.restoreSteps(g.action, g.pkg))
                } catch (e: AdbFailure) {
                    aborted = true
                    failed++
                    emit(ApplyEvent.ItemDone(i, groups.size, ApplyItemResult(g.pkg, g.name, false, e.userMessage)))
                    break
                }
                if (outcome.success) {
                    ok++
                    dao.markPackageRestored(g.pkg, System.currentTimeMillis())
                } else {
                    failed++
                    g.itemIds.forEach { dao.setItemStatus(it, ItemStatus.APPLIED, "Restore failed: ${outcome.message}", System.currentTimeMillis()) }
                }
                emit(ApplyEvent.ItemDone(i, groups.size, ApplyItemResult(g.pkg, g.name, outcome.success, outcome.message)))
            }
        }
        emit(ApplyEvent.Finished(ok, failed, aborted))
    }

    private suspend fun runSteps(steps: List<ShellStep>): Outcome {
        var last = Outcome(true, "OK")
        for (step in steps) {
            val result = adb.shell(step.command)
            val outcome = ShellParser.outcome(step.kind, result.output, result.exitCode)
            if (step.required) {
                if (!outcome.success) return outcome
                last = outcome
            }
        }
        return last
    }

    private fun tvLabel(): String = tv?.let { "${it.displayBrand} ${it.model}".trim() } ?: "Unknown TV"

    // ------------------------------------------------------------------ speed tweaks

    suspend fun trimCaches(): Outcome {
        val r = adb.shell(CommandBuilder.TRIM_CACHES, timeoutMs = 120_000)
        return ShellParser.outcome(com.tvcleaner.core.StepKind.TRIM_CACHES, r.output, r.exitCode)
    }

    suspend fun readAnimationScales(): AnimationScales {
        val values = CommandBuilder.ANIMATION_KEYS.map { key ->
            ShellParser.parseScale(adb.shell(CommandBuilder.getAnimationScale(key)).output)
        }
        return AnimationScales(values[0], values[1], values[2])
    }

    suspend fun setAnimationScale(scale: Float): Outcome {
        var last = Outcome(true, "Animation scale set to ${CommandBuilder.formatScale(scale)}x")
        for (step in CommandBuilder.animationSteps(scale)) {
            val r = adb.shell(step.command)
            val o = ShellParser.outcome(step.kind, r.output, r.exitCode)
            if (!o.success) return o
            last = Outcome(true, "Animation scale set to ${CommandBuilder.formatScale(scale)}x")
        }
        return last
    }

    suspend fun backgroundApps(): List<BackgroundApp> {
        val processes: List<ProcessInfo> = ShellParser.parseProcesses(adb.shell(CommandBuilder.LIST_PROCESSES).output)
        val installed = ShellParser.parsePackages(adb.shell("pm list packages").output)
        return processes
            .filter { it.pkg in installed }
            .map {
                val c = classifier.classify(it.pkg)
                BackgroundApp(it.pkg, c.name, it.rssKb?.takeIf { kb -> kb > 0 }, c)
            }
            .sortedByDescending { it.rssKb ?: 0L }
    }
}
