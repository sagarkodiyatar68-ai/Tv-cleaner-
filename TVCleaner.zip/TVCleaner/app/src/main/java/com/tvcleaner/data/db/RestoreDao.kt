package com.tvcleaner.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface RestoreDao {
    @Insert
    suspend fun insertBatch(batch: BatchEntity): Long

    @Insert
    suspend fun insertItems(items: List<ItemEntity>): List<Long>

    @Query("UPDATE items SET status = :status, message = :message, updatedAt = :now WHERE id = :id")
    suspend fun setItemStatus(id: Long, status: String, message: String?, now: Long)

    @Query("UPDATE items SET status = :to, updatedAt = :now WHERE batchId = :batchId AND status = :from")
    suspend fun bulkStatus(batchId: Long, from: String, to: String, now: Long)

    @Query("UPDATE batches SET succeeded = :succeeded, failed = :failed, finished = 1 WHERE id = :id")
    suspend fun finishBatch(id: Long, succeeded: Int, failed: Int)

    @Query(
        "UPDATE items SET status = 'RESTORED', updatedAt = :now " +
            "WHERE pkg = :pkg AND status = 'APPLIED' AND action IN ('DISABLE', 'REMOVE')",
    )
    suspend fun markPackageRestored(pkg: String, now: Long)

    @Transaction
    @Query("SELECT * FROM batches ORDER BY createdAt DESC")
    fun observeBatches(): Flow<List<BatchWithItems>>

    @Transaction
    @Query("SELECT * FROM batches ORDER BY createdAt DESC LIMIT :limit")
    suspend fun recentBatches(limit: Int): List<BatchWithItems>

    @Query("SELECT * FROM items WHERE status = 'APPLIED' AND action IN ('DISABLE', 'REMOVE') ORDER BY id DESC")
    suspend fun appliedRestorable(): List<ItemEntity>

    @Query("SELECT * FROM items WHERE batchId = :batchId AND status = 'APPLIED' AND action IN ('DISABLE', 'REMOVE')")
    suspend fun appliedInBatch(batchId: Long): List<ItemEntity>

    @Query("SELECT * FROM items WHERE pkg = :pkg AND status = 'APPLIED' AND action IN ('DISABLE', 'REMOVE')")
    suspend fun appliedForPackage(pkg: String): List<ItemEntity>

    @Query("SELECT COUNT(*) FROM items WHERE status = 'APPLIED' AND action IN ('DISABLE', 'REMOVE')")
    fun observeRestorableCount(): Flow<Int>

    @Query("DELETE FROM batches WHERE id = :id")
    suspend fun deleteBatch(id: Long)

    @Query("DELETE FROM batches")
    suspend fun clearAll()
}
