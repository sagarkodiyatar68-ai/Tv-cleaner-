package com.tvcleaner.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "tvcleaner_settings")

enum class ThemeMode { DARK, LIGHT, SYSTEM }

data class ConnectionPrefs(val host: String, val port: Int, val pairPort: String)

/** Small preferences store. Pairing codes are never persisted. */
class SettingsStore(private val context: Context) {
    private object Keys {
        val HOST = stringPreferencesKey("host")
        val PORT = intPreferencesKey("port")
        val PAIR_PORT = stringPreferencesKey("pair_port")
        val THEME = stringPreferencesKey("theme")
        val SAFE_MODE = booleanPreferencesKey("safe_mode")
        val LOAD_ICONS = booleanPreferencesKey("load_icons")
    }

    private val store: DataStore<Preferences> get() = context.settingsDataStore

    val connection: Flow<ConnectionPrefs> = store.data.map { p ->
        ConnectionPrefs(p[Keys.HOST] ?: "", p[Keys.PORT] ?: 5555, p[Keys.PAIR_PORT] ?: "")
    }

    val themeMode: Flow<ThemeMode> = store.data.map { p ->
        ThemeMode.values().firstOrNull { it.name == p[Keys.THEME] } ?: ThemeMode.DARK
    }

    val safeMode: Flow<Boolean> = store.data.map { it[Keys.SAFE_MODE] ?: false }

    val loadIcons: Flow<Boolean> = store.data.map { it[Keys.LOAD_ICONS] ?: true }

    suspend fun saveConnection(host: String, port: Int, pairPort: String) {
        store.edit {
            it[Keys.HOST] = host
            it[Keys.PORT] = port
            it[Keys.PAIR_PORT] = pairPort
        }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        store.edit { it[Keys.THEME] = mode.name }
    }

    suspend fun setSafeMode(enabled: Boolean) {
        store.edit { it[Keys.SAFE_MODE] = enabled }
    }

    suspend fun setLoadIcons(enabled: Boolean) {
        store.edit { it[Keys.LOAD_ICONS] = enabled }
    }
}
