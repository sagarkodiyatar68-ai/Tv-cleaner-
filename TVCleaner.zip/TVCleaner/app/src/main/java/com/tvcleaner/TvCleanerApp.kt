package com.tvcleaner

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.tvcleaner.adb.TvSession
import com.tvcleaner.core.PackageDb
import com.tvcleaner.data.CredentialStore
import com.tvcleaner.data.PackageDbLoader
import com.tvcleaner.data.SettingsStore
import com.tvcleaner.data.db.AppDatabase
import com.tvcleaner.domain.IconRepository
import com.tvcleaner.domain.TvRepository

class TvCleanerApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

/** Hand-wired dependencies (small app, no DI framework). */
class AppContainer(context: Context) {
    private val appContext: Context = context.applicationContext

    val settings = SettingsStore(appContext)
    val credentials = CredentialStore(appContext)
    val session = TvSession(credentials)
    val database: AppDatabase = Room.databaseBuilder(appContext, AppDatabase::class.java, "tvcleaner.db").build()
    val packageDb: PackageDb by lazy { PackageDbLoader.load(appContext) }
    val repository: TvRepository by lazy { TvRepository(session, database.restoreDao(), packageDb) }
    val icons = IconRepository(appContext, session)
}
