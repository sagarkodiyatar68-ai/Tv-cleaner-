package com.tvcleaner.core

/** Turns the bundled package_db.json text into a [PackageDb]. */
object PackageDbParser {
    fun parse(json: String): PackageDb {
        val root = MiniJson.parse(json) as? Map<*, *>
            ?: throw IllegalArgumentException("package_db.json: root must be an object")
        val version = root["version"] as? String ?: ""

        val entries = (root["packages"] as? List<*> ?: emptyList<Any?>()).mapNotNull { raw ->
            val m = raw as? Map<*, *> ?: return@mapNotNull null
            val pkg = m["pkg"] as? String ?: return@mapNotNull null
            DbEntry(
                pkg = pkg,
                name = m["name"] as? String ?: pkg,
                risk = Risk.parse(m["risk"] as? String ?: "UNKNOWN"),
                description = m["desc"] as? String ?: "",
                brands = brands(m["brands"]),
                flags = flags(m["flags"]),
            )
        }

        val patterns = (root["patterns"] as? List<*> ?: emptyList<Any?>()).mapNotNull { raw ->
            val m = raw as? Map<*, *> ?: return@mapNotNull null
            val value = m["value"] as? String ?: return@mapNotNull null
            val type = when ((m["type"] as? String)?.lowercase()) {
                "prefix" -> PatternType.PREFIX
                "contains" -> PatternType.CONTAINS
                "regex" -> PatternType.REGEX
                else -> return@mapNotNull null
            }
            DbPattern(
                type = type,
                value = value,
                risk = Risk.parse(m["risk"] as? String ?: "UNKNOWN"),
                description = m["desc"] as? String ?: "",
                brands = brands(m["brands"]),
                flags = flags(m["flags"]),
            )
        }
        return PackageDb(entries, patterns, version)
    }

    private fun brands(raw: Any?): Set<Brand> =
        (raw as? List<*> ?: emptyList<Any?>()).mapNotNull { (it as? String)?.let(Brand::parse) }.toSet()

    private fun flags(raw: Any?): Set<Flag> =
        (raw as? List<*> ?: emptyList<Any?>()).mapNotNull { (it as? String)?.let(Flag::parse) }.toSet()
}
