package com.tvcleaner.core

/** Builds the plain-text TV report that the user can share. */
object ReportBuilder {
    fun build(
        tv: TvInfo?,
        launcher: String?,
        apps: List<ScannedApp>,
        history: List<BatchSummary>,
        generatedAt: String,
    ): String = buildString {
        appendLine("TV Cleaner report")
        appendLine("Generated: $generatedAt")
        appendLine()
        if (tv != null) {
            appendLine("TV: ${tv.displayBrand} ${tv.model}".trim())
            appendLine("System: ${tv.androidText}")
            if (tv.device.isNotBlank()) appendLine("Device: ${tv.device}")
            if (tv.buildId.isNotBlank()) appendLine("Build: ${tv.buildId}")
        } else {
            appendLine("TV: not scanned")
        }
        appendLine("Launcher: ${launcher ?: "unknown"}")
        appendLine()

        val system = apps.count { it.isSystem }
        val third = apps.count { it.isThirdParty }
        val disabled = apps.filter { it.isDisabled }
        appendLine("Apps: ${apps.size} total, $system system, $third third-party, ${disabled.size} disabled")
        val active = apps.filter { !it.isDisabled }
        val counts = Risk.chipOrder.joinToString(", ") { r -> "${r.label} ${active.count { it.classification.risk == r }}" }
        appendLine("Enabled apps by risk: $counts")
        appendLine()

        val flagged = Flag.values().map { f -> f to active.filter { f in it.classification.flags } }.filter { it.second.isNotEmpty() }
        if (flagged.isNotEmpty()) {
            appendLine("Still enabled and flagged:")
            for ((flag, list) in flagged) {
                appendLine("  ${flag.label} (${list.size})")
                list.sortedBy { it.pkg }.take(MAX_LIST).forEach { appendLine("    - ${it.name} [${it.pkg}]") }
                if (list.size > MAX_LIST) appendLine("    ... and ${list.size - MAX_LIST} more")
            }
            appendLine()
        }

        if (disabled.isNotEmpty()) {
            appendLine("Disabled apps (${disabled.size}):")
            disabled.sortedBy { it.pkg }.forEach { appendLine("  - ${it.name} [${it.pkg}] ${it.classification.risk.label}") }
            appendLine()
        }

        if (history.isNotEmpty()) {
            appendLine("Recent changes:")
            history.forEach { appendLine("  ${it.timeText}: ${it.action}, ${it.succeeded} ok, ${it.failed} failed of ${it.total}") }
        }
    }.trimEnd() + "\n"

    private const val MAX_LIST = 25
}
