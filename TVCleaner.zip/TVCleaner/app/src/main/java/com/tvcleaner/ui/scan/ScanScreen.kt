package com.tvcleaner.ui.scan

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tvcleaner.adb.ConnectionState
import com.tvcleaner.core.CleanAction
import com.tvcleaner.core.Risk
import com.tvcleaner.core.ScannedApp
import com.tvcleaner.domain.AppVisual
import com.tvcleaner.ui.ConfirmRequest
import com.tvcleaner.ui.ScanUiState
import com.tvcleaner.ui.ScanViewModel
import com.tvcleaner.ui.ScopeFilter
import com.tvcleaner.ui.components.AppAvatar
import com.tvcleaner.ui.components.ApplyProgressDialog
import com.tvcleaner.ui.components.EmptyState
import com.tvcleaner.ui.components.FlagTag
import com.tvcleaner.ui.components.RiskChip
import com.tvcleaner.ui.components.ScreenHeader
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScanScreen(vm: ScanViewModel, connection: ConnectionState, onGoConnect: () -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val progress by vm.runner.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val connected = connection is ConnectionState.Connected

    Column(modifier = Modifier.fillMaxSize().imePadding()) {
        ScreenHeader(
            title = "Scan",
            subtitle = ui.tv?.let { "${it.displayBrand} ${it.model} • ${it.androidText}" },
            actions = {
                if (ui.scanned) {
                    IconButton(onClick = { scope.launch { shareReport(context, vm.reportText()) } }) {
                        Icon(Icons.Default.Share, contentDescription = "Share TV report")
                    }
                }
                IconButton(onClick = vm::scan, enabled = connected && !ui.loading) {
                    Icon(Icons.Default.Refresh, contentDescription = "Scan again")
                }
            },
        )

        when {
            !connected && !ui.scanned -> EmptyState(
                icon = Icons.Default.Tv,
                title = "Not connected",
                body = "Connect to your TV first, then scan it for preinstalled apps.",
                actionLabel = "Go to Connect",
                onAction = onGoConnect,
            )
            ui.loading -> Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                CircularProgressIndicator()
                Spacer(Modifier.size(16.dp))
                Text(ui.loadingStep, style = MaterialTheme.typography.bodyMedium)
            }
            ui.error != null && !ui.scanned -> EmptyState(
                icon = Icons.Default.Tv,
                title = "Scan failed",
                body = ui.error ?: "",
                actionLabel = if (connected) "Try again" else "Go to Connect",
                onAction = if (connected) vm::scan else onGoConnect,
            )
            !ui.scanned -> EmptyState(
                icon = Icons.Default.Search,
                title = "Ready to scan",
                body = "Reads the TV's brand, model, Android version and installed apps.",
                actionLabel = "Scan TV",
                onAction = vm::scan,
            )
            else -> ScanContent(ui = ui, vm = vm, connected = connected)
        }
    }

    ui.confirm?.let { req ->
        ConfirmDialog(req = req, safeMode = ui.safeMode, onConfirm = vm::confirmApply, onCancel = vm::cancelConfirm)
    }
    progress?.let { ApplyProgressDialog(it, onStop = vm.runner::stop, onClose = vm.runner::dismiss) }
    ui.message?.let { msg ->
        AlertDialog(
            onDismissRequest = vm::dismissMessage,
            confirmButton = { TextButton(onClick = vm::dismissMessage) { Text("OK") } },
            text = { Text(msg) },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScanContent(ui: ScanUiState, vm: ScanViewModel, connected: Boolean) {
    Column(modifier = Modifier.fillMaxSize()) {
        if (!connected) {
            Text(
                "Disconnected. Showing the last scan. Reconnect to make changes.",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
            )
        }
        ui.error?.let {
            Text(it, modifier = Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        val enabledCount = ui.apps.count { !it.isDisabled }
        Text(
            "${ui.apps.size} apps • $enabledCount enabled • ${ui.apps.count { it.isDisabled }} disabled" +
                (ui.launcher?.let { " • launcher: $it" } ?: ""),
            modifier = Modifier.padding(horizontal = 16.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )

        OutlinedTextField(
            value = ui.query,
            onValueChange = vm::onQuery,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            placeholder = { Text("Search apps or package names") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (ui.query.isNotEmpty()) {
                    IconButton(onClick = { vm.onQuery("") }) { Icon(Icons.Default.Close, contentDescription = "Clear search") }
                }
            },
            singleLine = true,
        )

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Safe mode", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                Text(
                    "Only SAFE items can be changed",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(checked = ui.safeMode, onCheckedChange = vm::setSafeMode)
        }

        LazyRow(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(Risk.chipOrder) { r ->
                FilterChip(
                    selected = r in ui.risks,
                    onClick = { vm.toggleRisk(r) },
                    label = { Text(r.label) },
                )
            }
        }
        LazyRow(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(ScopeFilter.values().toList()) { s ->
                FilterChip(selected = ui.scope == s, onClick = { vm.setScope(s) }, label = { Text(s.label) })
            }
            items(com.tvcleaner.core.Flag.values().toList()) { f ->
                FilterChip(selected = f in ui.flags, onClick = { vm.toggleFlag(f) }, label = { Text(f.label) })
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = vm::selectAllSafe, enabled = ui.safeCount > 0) { Text("Select all SAFE (${ui.safeCount})") }
            TextButton(onClick = vm::clearSelection, enabled = ui.selected.isNotEmpty()) { Text("Clear") }
        }
        HorizontalDivider()

        if (ui.visible.isEmpty()) {
            Text(
                "No apps match these filters.",
                modifier = Modifier.padding(24.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(ui.visible, key = { it.pkg }) { app ->
                AppRow(
                    app = app,
                    selected = app.pkg in ui.selected,
                    enabled = vm.canSelect(app),
                    loadIcons = ui.loadIcons,
                    vm = vm,
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            }
        }

        if (ui.selected.isNotEmpty()) {
            ActionBar(count = ui.selected.size, enabled = connected, onAction = vm::requestAction)
        }
    }
}

@Composable
private fun AppRow(app: ScannedApp, selected: Boolean, enabled: Boolean, loadIcons: Boolean, vm: ScanViewModel) {
    var visual by remember(app.pkg) { mutableStateOf<AppVisual?>(vm.cachedVisual(app.pkg)) }
    LaunchedEffect(app.pkg, loadIcons) {
        if (loadIcons && visual == null) visual = vm.loadVisual(app.pkg)
    }
    val c = app.classification
    val title = visual?.label ?: app.name

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled) { vm.toggle(app.pkg) }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = selected, onCheckedChange = null, enabled = enabled)
        Spacer(Modifier.size(8.dp))
        AppAvatar(visual = visual, name = title, risk = c.risk)
        Spacer(Modifier.size(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                if (app.isDisabled) {
                    Text("DISABLED", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                }
            }
            Text(
                app.pkg,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (c.description.isNotBlank()) {
                Text(
                    c.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (c.flags.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 2.dp)) {
                    c.flags.take(3).forEach { FlagTag(it) }
                }
            }
        }
        Spacer(Modifier.size(8.dp))
        RiskChip(c.risk)
    }
}

@Composable
private fun ActionBar(count: Int, enabled: Boolean, onAction: (CleanAction?) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Surface(tonalElevation = 6.dp, shadowElevation = 6.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("$count selected", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Button(onClick = { onAction(CleanAction.DISABLE) }, enabled = enabled) { Text("Disable") }
            OutlinedButton(onClick = { onAction(null) }, enabled = enabled) { Text("Restore") }
            Column {
                IconButton(onClick = { menu = true }, enabled = enabled) {
                    Icon(Icons.Default.MoreVert, contentDescription = "More actions")
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Remove for user 0") }, onClick = { menu = false; onAction(CleanAction.REMOVE) })
                    DropdownMenuItem(text = { Text("Force stop") }, onClick = { menu = false; onAction(CleanAction.FORCE_STOP) })
                    DropdownMenuItem(text = { Text("Clear cache") }, onClick = { menu = false; onAction(CleanAction.CLEAR_CACHE) })
                    DropdownMenuItem(text = { Text("Clear data") }, onClick = { menu = false; onAction(CleanAction.CLEAR_DATA) })
                }
            }
        }
    }
}

@Composable
private fun ConfirmDialog(req: ConfirmRequest, safeMode: Boolean, onConfirm: () -> Unit, onCancel: () -> Unit) {
    val action = req.action
    val verb = action?.label ?: "Restore"
    val counts = Risk.chipOrder.associateWith { r -> req.apps.count { it.classification.risk == r } }.filterValues { it > 0 }
    val notSafe = req.apps.count { it.classification.risk != Risk.SAFE }

    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("$verb ${req.apps.size} app${if (req.apps.size == 1) "" else "s"}?") },
        text = {
            Column(modifier = Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(explain(action), style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    counts.forEach { (risk, n) ->
                        RiskChip(risk)
                        Text("$n", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.size(4.dp))
                    }
                }
                if (notSafe > 0 && action != null && action != CleanAction.FORCE_STOP && !safeMode) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Text(
                            "$notSafe of these apps are not marked SAFE. Change them in small batches and check that the TV still works (Home, remote, inputs, Wi-Fi) before continuing.",
                            modifier = Modifier.padding(10.dp),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                        )
                    }
                }
                HorizontalDivider()
                req.apps.forEach { app ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(app.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(app.pkg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        RiskChip(app.classification.risk)
                    }
                }
            }
        },
        confirmButton = { Button(onClick = onConfirm) { Text(verb) } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
    )
}

private fun explain(action: CleanAction?): String = when (action) {
    CleanAction.DISABLE -> "Disabling hides the apps and stops them from running. You can undo it anytime from History / Restore. A restore list is saved before anything changes."
    CleanAction.REMOVE -> "Removes the apps for the TV's main user. The system copy stays on the TV, so they can be brought back from History / Restore, but it is a stronger change than Disable."
    CleanAction.FORCE_STOP -> "Stops the apps now. They may start again later. Nothing is uninstalled."
    CleanAction.CLEAR_CACHE -> "Clears temporary cache files (needs Android 12+ on the TV). Logins and settings are kept."
    CleanAction.CLEAR_DATA -> "Deletes the apps' data: logins, settings and downloads. This cannot be undone."
    null -> "Re-enables the apps so they work again."
}

private fun shareReport(context: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "TV Cleaner report")
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(send, "Share TV report").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
