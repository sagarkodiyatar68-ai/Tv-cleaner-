package com.tvcleaner.core

/**
 * Classifies packages using the bundled database.
 *
 * Rules, in order:
 * 1. Packages protected dynamically from the live TV (active launcher) are PROTECTED.
 * 2. A matching PROTECTED pattern (vendor services, tuner/input, providers...) always wins.
 * 3. An exact database entry decides the risk; flags from matching patterns are merged in.
 * 4. Otherwise the most restrictive matching pattern decides.
 * 5. Anything else is UNKNOWN.
 */
class Classifier(
    private val db: PackageDb,
    private val dynamicProtected: Map<String, String> = emptyMap(),
) {
    private val protectedPatterns = db.patterns.filter { it.risk == Risk.PROTECTED }

    /** Returns a copy that additionally protects [packages] (package -> reason). */
    fun withDynamicProtection(packages: Map<String, String>): Classifier =
        Classifier(db, dynamicProtected + packages)

    fun classify(pkg: String): Classification {
        val entry = db.byPkg[pkg]
        val matched = db.patterns.filter { it.matches(pkg) }
        val patternFlags = matched.flatMapTo(LinkedHashSet()) { it.flags }

        dynamicProtected[pkg]?.let { reason ->
            return Classification(
                pkg = pkg,
                risk = Risk.PROTECTED,
                name = entry?.name ?: friendlyName(pkg),
                description = reason,
                flags = (entry?.flags ?: emptySet()) + patternFlags,
                brands = entry?.brands ?: emptySet(),
                known = true,
                dynamicReason = reason,
            )
        }

        val protectedHit = protectedPatterns.firstOrNull { it.matches(pkg) }
        if (protectedHit != null) {
            return Classification(
                pkg = pkg,
                risk = Risk.PROTECTED,
                name = entry?.name ?: friendlyName(pkg),
                description = entry?.description?.takeIf { entry.risk == Risk.PROTECTED } ?: protectedHit.description,
                flags = (entry?.flags ?: emptySet()) + patternFlags,
                brands = entry?.brands ?: protectedHit.brands,
                known = true,
            )
        }

        if (entry != null) {
            return Classification(
                pkg = pkg,
                risk = entry.risk,
                name = entry.name,
                description = entry.description,
                flags = entry.flags + patternFlags,
                brands = entry.brands,
                known = true,
            )
        }

        if (matched.isNotEmpty()) {
            val top = matched.maxByOrNull { it.risk.restriction }!!
            return Classification(
                pkg = pkg,
                risk = top.risk,
                name = friendlyName(pkg),
                description = top.description,
                flags = patternFlags,
                brands = top.brands,
                known = true,
            )
        }

        return Classification(
            pkg = pkg,
            risk = Risk.UNKNOWN,
            name = friendlyName(pkg),
            description = "Not in the database. Research it before changing it.",
            flags = emptySet(),
            brands = emptySet(),
            known = false,
        )
    }

    companion object {
        private val GENERIC = setOf("app", "apps", "service", "services", "android", "tv", "main", "client", "core")

        /** Readable fallback name derived from the package name. */
        fun friendlyName(pkg: String): String {
            val parts = pkg.split('.').filter { it.isNotBlank() }
            if (parts.isEmpty()) return pkg
            var last = parts.last()
            if (last.lowercase() in GENERIC && parts.size >= 2) last = parts[parts.size - 2] + " " + last
            return last.replace('_', ' ').replaceFirstChar { it.uppercase() }
        }
    }
}
