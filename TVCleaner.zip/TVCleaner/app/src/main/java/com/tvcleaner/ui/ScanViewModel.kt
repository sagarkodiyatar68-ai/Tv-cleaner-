package com.tvcleaner.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tvcleaner.AppContainer
import com.tvcleaner.adb.AdbFailure
import com.tvcleaner.core.BatchSummary
import com.tvcleaner.core.CleanAction
import com.tvcleaner.core.Flag
import com.tvcleaner.core.ReportBuilder
import com.tvcleaner.core.Risk
import com.tvcleaner.core.ScannedApp
import com.tvcleaner.core.TvInfo
import com.tvcleaner.domain.AppVisual
import com.tvcleaner.domain.toTarget
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

enum class ScopeFilter(val label: String) {
    ALL("All"), ENABLED("Enabled"), DISABLED("Disabled"), SYSTEM("System"), USER("User")
}

/** [action] == null means "restore the selected disabled apps". */
data class ConfirmRequest(val action: CleanAction?, val apps: List<ScannedApp>)

data class ScanUiState(
    val loading: Boolean = false,
    val loadingStep: String = "",
    val error: String? = null,
    val message: String? = null,
    val tv: TvInfo? = null,
    val launcher: String? = null,
    val apps: List<ScannedApp> = emptyList(),
    val visible: List<ScannedApp> = emptyList(),
    val query: String = "",
    val risks: Set<Risk> = emptySet(),
    val scope: ScopeFilter = ScopeFilter.ALL,
    val flags: Set<Flag> = emptySet(),
    val selected: Set<String> = emptySet(),
    val safeMode: Boolean = false,
    val loadIcons: Boolean = true,
    val confirm: ConfirmRequest? = null,
    val scanned: Boolean = false,
) {
    val safeCount: Int get() = apps.count { it.classification.risk == Risk.SAFE && !it.isDisabled }
}

class ScanViewModel(private val container: AppContainer) : ViewModel() {
    private val repo get() = container.repository
    private val session = container.session

    private val _ui = MutableStateFlow(ScanUiState())
    val ui: StateFlow<ScanUiState> = _ui.asStateFlow()

    val runner = ApplyRunner(viewModelScope)

    init {
        viewModelScope.launch {
            val safe = container.settings.safeMode.first()
            update { it.copy(safeMode = safe) }
        }
        viewModelScope.launch {
            container.settings.loadIcons.collect { enabled -> update { it.copy(loadIcons = enabled) } }
        }
    }

    // ------------------------------------------------------------------ state helpers

    private fun update(block: (ScanUiState) -> ScanUiState) {
        _ui.update { old ->
            val next = block(old)
            next.copy(visible = filtered(next))
        }
    }

    private fun filtered(s: ScanUiState): List<ScannedApp> {
        val q = s.query.trim().lowercase()
        return s.apps.asSequence()
            .filter { s.risks.isEmpty() || it.classification.risk in s.risks }
            .filter {
                when (s.scope) {
                    ScopeFilter.ALL -> true
                    ScopeFilter.ENABLED -> !it.isDisabled
                    ScopeFilter.DISABLED -> it.isDisabled
                    ScopeFilter.SYSTEM -> it.isSystem
                    ScopeFilter.USER -> it.isThirdParty
                }
            }
            .filter { s.flags.isEmpty() || s.flags.any { f -> f in it.classification.flags } }
            .filter { q.isEmpty() || it.name.lowercase().contains(q) || it.pkg.lowercase().contains(q) }
            .sortedWith(
                compareBy<ScannedApp> { Risk.chipOrder.indexOf(it.classification.risk) }
                    .thenBy { it.name.lowercase() },
            )
            .toList()
    }

    // ------------------------------------------------------------------ scan

    fun scan() {
        if (_ui.value.loading) return
        if (!session.isConnected) {
            update { it.copy(error = "Connect to the TV first.") }
            return
        }
        viewModelScope.launch {
            update { it.copy(loading = true, loadingStep = "Starting scan...", error = null, message = null) }
            try {
                val result = repo.scan { step -> update { s -> s.copy(loadingStep = step) } }
                update {
                    it.copy(
                        loading = false,
                        tv = result.tv,
                        launcher = result.launcher,
                        apps = result.apps,
                        selected = emptySet(),
                        scanned = true,
                    )
                }
            } catch (e: AdbFailure) {
                update { it.copy(loading = false, error = e.userMessage) }
            } catch (e: Exception) {
                update { it.copy(loading = false, error = e.message ?: "Scan failed.") }
            }
        }
    }

    // ------------------------------------------------------------------ filters & selection

    fun onQuery(q: String) = update { it.copy(query = q) }

    fun toggleRisk(r: Risk) = update { it.copy(risks = if (r in it.risks) it.risks - r else it.risks + r) }

    fun setScope(s: ScopeFilter) = update { it.copy(scope = s) }

    fun toggleFlag(f: Flag) = update { it.copy(flags = if (f in it.flags) it.flags - f else it.flags + f) }

    fun canSelect(app: ScannedApp): Boolean =
        app.classification.selectable && (!_ui.value.safeMode || app.classification.risk == Risk.SAFE || app.isDisabled)

    fun toggle(pkg: String) = update { s ->
        val app = s.apps.firstOrNull { it.pkg == pkg } ?: return@update s
        if (!canSelect(app)) return@update s
        s.copy(selected = if (pkg in s.selected) s.selected - pkg else s.selected + pkg)
    }

    fun selectAllSafe() = update { s ->
        s.copy(
            selected = s.apps
                .filter { it.classification.risk == Risk.SAFE && it.classification.selectable && !it.isDisabled }
                .map { it.pkg }
                .toSet(),
        )
    }

    fun clearSelection() = update { it.copy(selected = emptySet()) }

    fun setSafeMode(enabled: Boolean) {
        update { s ->
            val kept = if (enabled) {
                s.selected.filter { pkg ->
                    s.apps.firstOrNull { it.pkg == pkg }?.let { it.classification.risk == Risk.SAFE || it.isDisabled } == true
                }.toSet()
            } else {
                s.selected
            }
            s.copy(safeMode = enabled, selected = kept)
        }
        viewModelScope.launch { container.settings.setSafeMode(enabled) }
    }

    fun dismissMessage() = update { it.copy(message = null) }

    // ------------------------------------------------------------------ actions

    /** [action] == null requests a restore of the selected disabled apps. */
    fun requestAction(action: CleanAction?) {
        val s = _ui.value
        if (!session.isConnected) {
            update { it.copy(message = "You're not connected to the TV.") }
            return
        }
        val chosen = s.apps.filter { it.pkg in s.selected && it.classification.selectable }
        var apps = when (action) {
            null -> chosen.filter { it.isDisabled }
            CleanAction.DISABLE -> chosen.filter { !it.isDisabled }
            else -> chosen
        }
        if (s.safeMode && action != null) apps = apps.filter { it.classification.risk == Risk.SAFE }
        if (apps.isEmpty()) {
            update { it.copy(message = "Nothing to do for this selection.") }
            return
        }
        update { it.copy(confirm = ConfirmRequest(action, apps)) }
    }

    fun cancelConfirm() = update { it.copy(confirm = null) }

    fun confirmApply() {
        val req = _ui.value.confirm ?: return
        val safe = _ui.value.safeMode
        update { it.copy(confirm = null) }
        val targets = req.apps.map { it.toTarget() }
        val events = if (req.action == null) repo.restoreApps(targets) else repo.apply(req.action, targets, safe)
        val title = (req.action?.label ?: "Restore") + " (${targets.size})"
        runner.run(title, events) {
            if (session.isConnected) scan()
        }
    }

    // ------------------------------------------------------------------ icons & report

    fun cachedVisual(pkg: String): AppVisual? = container.icons.cached(pkg)

    suspend fun loadVisual(pkg: String): AppVisual? = try {
        container.icons.load(pkg)
    } catch (e: AdbFailure) {
        null
    }

    suspend fun reportText(): String {
        val s = _ui.value
        val fmt = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        val history = container.database.restoreDao().recentBatches(5).map {
            BatchSummary(fmt.format(Date(it.batch.createdAt)), it.batch.action, it.batch.total, it.batch.succeeded, it.batch.failed)
        }
        return ReportBuilder.build(s.tv, s.launcher, s.apps, history, fmt.format(Date()))
    }
}
