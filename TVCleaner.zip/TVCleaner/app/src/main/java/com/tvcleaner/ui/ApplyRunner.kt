package com.tvcleaner.ui

import com.tvcleaner.adb.AdbFailure
import com.tvcleaner.domain.ApplyEvent
import com.tvcleaner.domain.ApplyItemResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** What the progress dialog shows while a batch is applied or restored. */
data class ApplyUiState(
    val title: String,
    val total: Int = 0,
    val done: Int = 0,
    val current: String? = null,
    val results: List<ApplyItemResult> = emptyList(),
    val finished: Boolean = false,
    val aborted: Boolean = false,
    val stopped: Boolean = false,
) {
    val succeeded: Int get() = results.count { it.success }
    val failed: Int get() = results.count { !it.success }
}

/** Runs one apply/restore flow at a time and exposes live progress for [ApplyProgressDialog]. */
class ApplyRunner(private val scope: CoroutineScope) {
    private val _state = MutableStateFlow<ApplyUiState?>(null)
    val state: StateFlow<ApplyUiState?> = _state.asStateFlow()
    private var job: Job? = null

    val isRunning: Boolean get() = _state.value?.finished == false

    fun run(title: String, events: Flow<ApplyEvent>, onFinished: () -> Unit = {}) {
        job?.cancel()
        _state.value = ApplyUiState(title)
        job = scope.launch {
            try {
                events.collect { event -> _state.update { s -> s?.let { reduce(it, event) } } }
            } catch (e: CancellationException) {
                throw e
            } catch (e: AdbFailure) {
                fail(e.userMessage)
            } catch (e: Exception) {
                fail(e.message ?: e.javaClass.simpleName)
            }
            onFinished()
        }
    }

    /** Stops after the command that is running right now. Items not reached stay untouched. */
    fun stop() {
        job?.cancel()
        _state.update { it?.copy(finished = true, stopped = true, current = null) }
    }

    fun dismiss() {
        if (isRunning) return
        _state.value = null
    }

    private fun fail(message: String) {
        _state.update { s ->
            s?.copy(
                results = s.results + ApplyItemResult("", "Error", false, message),
                finished = true,
                aborted = true,
                current = null,
            )
        }
    }

    private fun reduce(s: ApplyUiState, e: ApplyEvent): ApplyUiState = when (e) {
        is ApplyEvent.Started -> s.copy(total = e.total)
        is ApplyEvent.Progress -> s.copy(current = e.name)
        is ApplyEvent.ItemDone -> s.copy(done = s.done + 1, results = s.results + e.result, current = null)
        is ApplyEvent.Finished -> s.copy(finished = true, aborted = e.aborted, current = null)
    }
}
