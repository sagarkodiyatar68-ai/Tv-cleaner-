package com.tvcleaner.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class MiscCoreTest {
    @Test fun brandDetection() {
        assertEquals(Brand.HAIER, BrandDetector.detect("Haier", "Haier", "H32S80EFX", "deto"))
        assertEquals(Brand.TCL, BrandDetector.detect("TCL", "TCL", "55C735", "G07"))
        assertEquals(Brand.XIAOMI, BrandDetector.detect("Xiaomi", "Xiaomi", "MiTV-AXSO0", "dangal"))
        assertEquals(Brand.SONY, BrandDetector.detect("Sony", "Sony", "BRAVIA 4K VH2", "BRAVIA_VH2"))
        assertEquals(Brand.HISENSE, BrandDetector.detect("Hisense", "Hisense", "HiSmartTV A4", "xiaoyushan"))
        assertEquals(Brand.PHILIPS, BrandDetector.detect("TP Vision", "Philips", "TPM191E", "PH9M"))
        assertEquals(Brand.NVIDIA_SHIELD, BrandDetector.detect("NVIDIA", "NVIDIA", "SHIELD Android TV", "foster"))
        assertEquals(Brand.CHROMECAST_GTV, BrandDetector.detect("Google", "google", "Chromecast", "sabrina"))
        assertEquals(Brand.OTHER, BrandDetector.detect("Acme", "Acme", "TV1", "tv1"))
    }

    @Test fun miniJsonParsesNestedValues() {
        val v = MiniJson.parse("""{"a":[1,2.5,"x\n\u0041",true,null],"b":{"c":"d"}}""") as Map<*, *>
        val a = v["a"] as List<*>
        assertEquals(1.0, a[0])
        assertEquals(2.5, a[1])
        assertEquals("x\nA", a[2])
        assertEquals(true, a[3])
        assertNull(a[4])
        assertEquals("d", (v["b"] as Map<*, *>)["c"])
    }

    @Test fun miniJsonRejectsGarbage() {
        listOf("{", "[1,", "{\"a\" 1}", "nope", "{} x").forEach {
            try {
                MiniJson.parse(it)
                fail("should reject: $it")
            } catch (_: IllegalArgumentException) {
            }
        }
    }

    @Test fun reportListsDisabledAndFlaggedApps() {
        val c = TestDb.classifier
        fun app(pkg: String, disabled: Boolean) =
            c.classify(pkg).let { ScannedApp(pkg, it.name, isSystem = true, isThirdParty = false, isDisabled = disabled, classification = it) }
        val apps = listOf(app("tv.samba.ssm", false), app("com.sony.dtv.promos", true), app("com.android.vending", false))
        val tv = TvInfo("Sony", "Sony", "KD-55X80J", "BRAVIA_VH2", "12", 31, "build", Brand.SONY)
        val text = ReportBuilder.build(tv, "com.google.android.tvlauncher", apps, listOf(BatchSummary("2026-11-12 10:00", "Disable", 3, 2, 1)), "now")
        assertTrue(text.contains("TV: Sony KD-55X80J"))
        assertTrue(text.contains("Android 12 (API 31)"))
        assertTrue(text.contains("ACR / tracking (1)"))
        assertTrue(text.contains("[com.sony.dtv.promos] Safe"))
        assertTrue(text.contains("Disable, 2 ok, 1 failed of 3"))
    }
}

class HostValidatorTest {
    @Test fun acceptsPrivateAndLocalAddresses() {
        listOf(
            "192.168.1.50", "10.0.0.20", "172.16.5.4", "172.31.255.1", "169.254.10.2", "100.101.102.103",
            "127.0.0.1", "fe80::1", "fd12:3456::7", "::1", "livingroom-tv.local",
        ).forEach { assertTrue(it, HostValidator.validate(it) == null) }
    }

    @Test fun rejectsPublicAddressesAndNames() {
        listOf(
            "8.8.8.8", "1.1.1.1", "172.32.0.1", "172.15.0.1", "192.169.0.1", "100.128.0.1", "example.com",
            "tv", "2001:4860:4860::8888", "256.1.1.1", "192.168.1", "192.168.1.1.1", ".local", "",
        ).forEach { assertTrue(it, HostValidator.validate(it) != null) }
    }

    @Test fun ignoresIpv6ZoneId() {
        assertTrue(HostValidator.isLocalAddress("fe80::1%wlan0"))
    }
}
