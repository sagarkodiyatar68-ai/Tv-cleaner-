package com.tvcleaner.domain

import com.tvcleaner.adb.AdbFailure
import com.tvcleaner.core.Brand
import com.tvcleaner.core.CleanAction
import com.tvcleaner.core.Risk
import com.tvcleaner.core.TestDb
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TvRepositoryTest {
    private val log = EventLog()
    private val tv = FakeTv(log)
    private val dao = FakeDao(log)
    private val repo = TvRepository(tv, dao, TestDb.db)

    private fun scan() = runBlocking { repo.scan() }

    private fun targets(vararg pkgs: String): List<ApplyTarget> {
        val result = scan()
        return pkgs.map { p -> result.apps.first { it.pkg == p }.toTarget() }
    }

    private fun run(action: CleanAction, t: List<ApplyTarget>, safe: Boolean = false) =
        runBlocking { repo.apply(action, t, safe).toList() }

    @Test fun scanReadsTvAndClassifiesApps() {
        val r = scan()
        assertEquals("KD-55X80J", r.tv.model)
        assertEquals(Brand.SONY, r.tv.brand)
        assertEquals(31, r.tv.sdk)
        assertEquals(setOf("com.google.android.tvlauncher", "com.android.vending", "com.android.systemui", "tv.samba.ssm", "com.sony.dtv.promos", "com.sony.dtv.demomode", "com.example.mystery", "com.tcl.somethingnew", "com.example.game"), r.apps.map { it.pkg }.toSet())
        assertEquals(Risk.SAFE, r.apps.first { it.pkg == "tv.samba.ssm" }.classification.risk)
        assertEquals(Risk.UNKNOWN, r.apps.first { it.pkg == "com.example.mystery" }.classification.risk)
        assertTrue(r.apps.first { it.pkg == "com.example.game" }.isThirdParty)
    }

    @Test fun activeLauncherIsProtectedFromTheTv() {
        tv.system += "com.example.homeapp"
        tv.homePackage = "com.example.homeapp"
        val r = scan()
        assertEquals("com.example.homeapp", r.launcher)
        val c = r.apps.first { it.pkg == "com.example.homeapp" }.classification
        assertEquals(Risk.PROTECTED, c.risk)
        assertTrue(c.dynamicReason != null)
    }

    @Test fun disabledStateComesFromTheTv() {
        tv.disabled += "tv.samba.ssm"
        assertTrue(scan().apps.first { it.pkg == "tv.samba.ssm" }.isDisabled)
    }

    @Test fun restoreListIsSavedBeforeTheFirstChangeCommand() {
        val t = targets("tv.samba.ssm", "com.sony.dtv.promos")
        log.events.clear()
        run(CleanAction.DISABLE, t)
        val firstShell = log.events.indexOfFirst { it.startsWith("shell:pm disable-user") }
        assertTrue(log.events.indexOf("db:insertBatch") in 0 until firstShell)
        assertTrue(log.events.indexOf("db:insertItems(2)") in 0 until firstShell)
    }

    @Test fun disableAppliesOneAtATimeWithProgress() {
        val t = targets("tv.samba.ssm", "com.sony.dtv.promos")
        val events = run(CleanAction.DISABLE, t)
        assertTrue(events.first() is ApplyEvent.Started)
        assertTrue(events.last() is ApplyEvent.Finished)
        // Progress / ItemDone alternate, never overlap.
        val kinds = events.drop(1).dropLast(1).map { it::class.simpleName }
        assertEquals(listOf("Progress", "ItemDone", "Progress", "ItemDone"), kinds)
        assertEquals(setOf("tv.samba.ssm", "com.sony.dtv.promos"), tv.disabled)
        val fin = events.last() as ApplyEvent.Finished
        assertEquals(2, fin.succeeded)
        assertEquals(0, fin.failed)
        assertTrue(dao.items.values.all { it.status == "APPLIED" })
        assertTrue(dao.batches.values.single().finished)
    }

    @Test fun protectedAppsAreNeverTouched() {
        val t = targets("com.android.vending", "com.android.systemui", "com.google.android.tvlauncher", "tv.samba.ssm")
        run(CleanAction.DISABLE, t)
        assertEquals(setOf("tv.samba.ssm"), tv.disabled)
        assertFalse(tv.commands.any { it.contains("com.android.vending") && it.startsWith("pm disable") })
    }

    @Test fun safeModeOnlyAppliesSafeItems() {
        val t = targets("tv.samba.ssm", "com.example.mystery", "com.tcl.somethingnew")
        run(CleanAction.DISABLE, t, safe = true)
        assertEquals(setOf("tv.samba.ssm"), tv.disabled)
        assertEquals(1, dao.items.size)
    }

    @Test fun failuresAreReportedPerAppAndTheBatchContinues() {
        tv.denyChanges += "tv.samba.ssm"
        val t = targets("tv.samba.ssm", "com.sony.dtv.promos")
        val events = run(CleanAction.DISABLE, t)
        val done = events.filterIsInstance<ApplyEvent.ItemDone>().map { it.result }
        assertFalse(done[0].success)
        assertTrue(done[0].message.startsWith("Blocked by the TV"))
        assertTrue(done[1].success)
        val fin = events.last() as ApplyEvent.Finished
        assertEquals(1, fin.succeeded)
        assertEquals(1, fin.failed)
        assertEquals(setOf("FAILED", "APPLIED"), dao.items.values.map { it.status }.toSet())
    }

    @Test fun launcherChangedAfterScanIsStillProtected() {
        val t = targets("tv.samba.ssm", "com.example.mystery")
        tv.homePackage = "com.example.mystery" // user switched launcher after the scan
        val events = run(CleanAction.DISABLE, t)
        assertEquals(setOf("tv.samba.ssm"), tv.disabled)
        val skipped = events.filterIsInstance<ApplyEvent.ItemDone>().first { it.result.pkg == "com.example.mystery" }
        assertFalse(skipped.result.success)
    }

    @Test fun connectionLossAbortsAndLeavesRemainingItemsSkipped() {
        val t = targets("tv.samba.ssm", "com.sony.dtv.promos", "com.sony.dtv.demomode")
        // scan used some commands; drop the connection on the 2nd change command
        val base = tv.commands.size
        tv.disconnectAtCommandNumber = base + 1 /*re-resolve launcher*/ + 2
        val events = run(CleanAction.DISABLE, t)
        val fin = events.last() as ApplyEvent.Finished
        assertTrue(fin.aborted)
        val statuses = dao.items.values.sortedBy { it.id }.map { it.status }
        assertEquals(listOf("APPLIED", "FAILED", "SKIPPED"), statuses)
        assertTrue(dao.batches.values.single().finished)
    }

    @Test fun removeThenRestoreBringsTheAppBack() {
        val t = targets("com.sony.dtv.promos")
        run(CleanAction.REMOVE, t)
        assertTrue("com.sony.dtv.promos" in tv.removed)
        assertTrue(tv.commands.any { it == "pm uninstall -k --user 0 com.sony.dtv.promos" })

        val events = runBlocking { repo.restoreAll().toList() }
        assertTrue("com.sony.dtv.promos" !in tv.removed)
        assertTrue(tv.commands.contains("cmd package install-existing com.sony.dtv.promos"))
        assertEquals(1, (events.last() as ApplyEvent.Finished).succeeded)
        assertEquals("RESTORED", dao.items.values.single().status)
    }

    @Test fun restoreAllReEnablesDisabledApps() {
        val t = targets("tv.samba.ssm", "com.sony.dtv.promos")
        run(CleanAction.DISABLE, t)
        assertEquals(2, tv.disabled.size)
        runBlocking { repo.restoreAll().toList() }
        assertTrue(tv.disabled.isEmpty())
        assertTrue(dao.items.values.all { it.status == "RESTORED" })
    }

    @Test fun restoreBatchOnlyTouchesThatBatch() {
        run(CleanAction.DISABLE, targets("tv.samba.ssm"))
        run(CleanAction.DISABLE, targets("com.sony.dtv.promos"))
        runBlocking { repo.restoreBatch(1L).toList() }
        assertEquals(setOf("com.sony.dtv.promos"), tv.disabled)
    }

    @Test fun packageDisabledThenRemovedIsRestoredOnce() {
        run(CleanAction.DISABLE, targets("com.sony.dtv.promos"))
        run(CleanAction.REMOVE, targets("com.sony.dtv.promos"))
        val events = runBlocking { repo.restoreAll().toList() }
        assertEquals(1, events.filterIsInstance<ApplyEvent.ItemDone>().size)
        assertTrue(dao.items.values.all { it.status == "RESTORED" })
    }

    @Test fun forceStopDoesNotWriteARestoreList() {
        val t = targets("tv.samba.ssm")
        log.events.clear()
        val events = run(CleanAction.FORCE_STOP, t)
        assertTrue(dao.batches.isEmpty())
        assertTrue(tv.commands.contains("am force-stop tv.samba.ssm"))
        assertEquals(1, (events.last() as ApplyEvent.Finished).succeeded)
    }

    @Test fun disconnectedScanFailsCleanly() {
        tv.disconnectAtCommandNumber = 1
        var failure: Throwable? = null
        try { runBlocking { repo.scan() } } catch (e: AdbFailure) { failure = e }
        assertTrue(failure is AdbFailure.Disconnected)
        assertNull(repo.tv)
    }

    @Test fun animationScaleWritesAllThreeSettings() {
        val o = runBlocking { repo.setAnimationScale(0.5f) }
        assertTrue(o.success)
        assertEquals(
            listOf(
                "settings put global window_animation_scale 0.5",
                "settings put global transition_animation_scale 0.5",
                "settings put global animator_duration_scale 0.5",
            ),
            tv.commands.filter { it.startsWith("settings put") },
        )
    }
}
