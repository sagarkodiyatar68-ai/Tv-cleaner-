package com.tvcleaner.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Integrity checks on the bundled package_db.json. */
class PackageDbTest {
    private val db = TestDb.db

    @Test fun hasAtLeast150Entries() {
        assertTrue("entries=${db.entries.size}", db.entries.size >= 150)
    }

    @Test fun noDuplicatePackages() {
        val dups = db.entries.groupBy { it.pkg }.filter { it.value.size > 1 }.keys
        assertTrue("duplicates: $dups", dups.isEmpty())
    }

    @Test fun allPackageNamesAreValid() {
        db.entries.forEach { assertTrue(it.pkg, CommandBuilder.isValidPackage(it.pkg)) }
    }

    @Test fun everyRiskLevelIsUsed() {
        val used = db.entries.map { it.risk }.toSet()
        assertTrue(Risk.SAFE in used && Risk.TEST in used && Risk.PROTECTED in used)
    }

    @Test fun everyRequestedBrandHasEntries() {
        val wanted = listOf(
            Brand.HAIER, Brand.TCL, Brand.XIAOMI, Brand.SONY, Brand.HISENSE, Brand.PHILIPS,
            Brand.NVIDIA_SHIELD, Brand.CHROMECAST_GTV,
        )
        wanted.forEach { b ->
            assertTrue("no entries for $b", db.entries.any { b in it.brands })
        }
        assertTrue(db.entries.any { Brand.ALL in it.brands })
    }

    @Test fun everyFlagIsUsed() {
        val used = db.entries.flatMap { it.flags }.toSet()
        Flag.values().forEach { assertTrue("flag $it unused", it in used) }
    }

    @Test fun everyEntryHasADescription() {
        db.entries.forEach { assertFalse(it.pkg, it.description.isBlank()) }
    }

    @Test fun noSafeEntryIsCoveredByAProtectedPattern() {
        val protectedPatterns = db.patterns.filter { it.risk == Risk.PROTECTED }
        val bad = db.entries.filter { e -> e.risk == Risk.SAFE && protectedPatterns.any { it.matches(e.pkg) } }
        assertTrue("SAFE but protected by pattern: ${bad.map { it.pkg }}", bad.isEmpty())
    }

    @Test fun classifierAgreesWithEntryRiskForEveryEntry() {
        // A pattern may only make an entry stricter (PROTECTED), never looser.
        val c = TestDb.classifier
        db.entries.forEach { e ->
            val r = c.classify(e.pkg).risk
            if (r != e.risk) assertEquals("${e.pkg} entry=${e.risk}", Risk.PROTECTED, r)
        }
    }

    @Test fun protectedCategoriesFromTheSpecArePresent() {
        val c = TestDb.classifier
        // launcher, Play Services, Play Store, SystemUI, WebView, TV settings, vendor, input, tuner
        listOf(
            "com.google.android.tvlauncher", "com.google.android.gms", "com.android.vending", "com.android.systemui",
            "com.google.android.webview", "com.android.tv.settings", "com.mediatek.anything", "com.realtek.anything",
            "com.amlogic.anything", "com.x.tvinput", "com.x.tuner",
        ).forEach { assertEquals(it, Risk.PROTECTED, c.classify(it).risk) }
    }

    @Test fun regexPatternsCompile() {
        db.patterns.filter { it.type == PatternType.REGEX }.forEach { it.matches("com.example.app") }
    }
}
