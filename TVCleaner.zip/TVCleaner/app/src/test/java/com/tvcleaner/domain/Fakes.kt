package com.tvcleaner.domain

import com.tvcleaner.adb.AdbFailure
import com.tvcleaner.adb.AdbShell
import com.tvcleaner.adb.ShellResult
import com.tvcleaner.data.db.BatchEntity
import com.tvcleaner.data.db.BatchWithItems
import com.tvcleaner.data.db.ItemEntity
import com.tvcleaner.data.db.RestoreDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

/** Shared, ordered log so tests can check what happened before what. */
class EventLog {
    val events = mutableListOf<String>()
    fun add(e: String) { events += e }
}

/** A pretend TV: answers the shell commands the app sends and remembers package state. */
class FakeTv(private val log: EventLog) : AdbShell {
    val system = linkedSetOf(
        "com.google.android.tvlauncher", "com.android.vending", "com.android.systemui",
        "tv.samba.ssm", "com.sony.dtv.promos", "com.sony.dtv.demomode", "com.example.mystery", "com.tcl.somethingnew",
    )
    val thirdParty = linkedSetOf("com.example.game")
    val disabled = linkedSetOf<String>()
    val removed = linkedSetOf<String>()
    var homePackage = "com.google.android.tvlauncher"
    val denyChanges = mutableSetOf<String>()
    var disconnectAtCommandNumber: Int? = null
    val commands = mutableListOf<String>()

    private fun lines(pkgs: Collection<String>) = pkgs.joinToString("\r\n") { "package:$it" }

    override suspend fun shell(command: String, timeoutMs: Long): ShellResult {
        commands += command
        if (command.startsWith("pm ") || command.startsWith("cmd package") || command.startsWith("am ")) log.add("shell:$command")
        disconnectAtCommandNumber?.let { if (commands.size >= it) throw AdbFailure.Disconnected() }
        val pkg = command.substringAfterLast(' ')
        return when {
            command == "getprop" -> ShellResult(
                "[ro.product.manufacturer]: [Sony]\r\n[ro.product.brand]: [Sony]\r\n[ro.product.model]: [KD-55X80J]\r\n" +
                    "[ro.product.device]: [BRAVIA_VH2]\r\n[ro.build.version.release]: [12]\r\n[ro.build.version.sdk]: [31]\r\n",
                0,
            )
            command == "pm list packages -s" -> ShellResult(lines((system - removed)), 0)
            command == "pm list packages -3" -> ShellResult(lines(thirdParty - removed), 0)
            command == "pm list packages -d" -> ShellResult(lines(disabled - removed), 0)
            command.startsWith("cmd package resolve-activity") ->
                ShellResult("priority=0 preferredOrder=0 match=0x108000\r\n$homePackage/.MainActivity\r\n", 0)
            command.startsWith("pm disable-user") ->
                if (pkg in denyChanges) ShellResult("java.lang.SecurityException: Shell cannot change component state for $pkg/.A to 3", 255)
                else { disabled += pkg; ShellResult("Package $pkg new state: disabled-user", 0) }
            command.startsWith("pm enable") -> {
                if (pkg in removed) ShellResult("Error: java.lang.IllegalArgumentException: Unknown package: $pkg", 1)
                else { disabled -= pkg; ShellResult("Package $pkg new state: enabled", 0) }
            }
            command.startsWith("pm uninstall -k") -> { removed += pkg; ShellResult("Success", 0) }
            command.startsWith("cmd package install-existing") -> { removed -= pkg; ShellResult("Package $pkg installed for user: 0", 0) }
            command.startsWith("am force-stop") -> ShellResult("", 0)
            else -> ShellResult("", 0)
        }
    }
}

/** In-memory stand-in for the Room DAO. Logs writes into the shared [EventLog]. */
class FakeDao(private val log: EventLog) : RestoreDao {
    val batches = mutableMapOf<Long, BatchEntity>()
    val items = mutableMapOf<Long, ItemEntity>()
    private var nextBatch = 1L
    private var nextItem = 1L

    override suspend fun insertBatch(batch: BatchEntity): Long {
        val id = nextBatch++
        batches[id] = batch.copy(id = id)
        log.add("db:insertBatch")
        return id
    }

    override suspend fun insertItems(items: List<ItemEntity>): List<Long> {
        log.add("db:insertItems(${items.size})")
        return items.map { val id = nextItem++; this.items[id] = it.copy(id = id); id }
    }

    override suspend fun setItemStatus(id: Long, status: String, message: String?, now: Long) {
        items[id] = items.getValue(id).copy(status = status, message = message, updatedAt = now)
    }

    override suspend fun bulkStatus(batchId: Long, from: String, to: String, now: Long) {
        items.replaceAll { _, v -> if (v.batchId == batchId && v.status == from) v.copy(status = to) else v }
    }

    override suspend fun finishBatch(id: Long, succeeded: Int, failed: Int) {
        batches[id] = batches.getValue(id).copy(succeeded = succeeded, failed = failed, finished = true)
    }

    override suspend fun markPackageRestored(pkg: String, now: Long) {
        items.replaceAll { _, v ->
            if (v.pkg == pkg && v.status == "APPLIED" && v.action in setOf("DISABLE", "REMOVE")) v.copy(status = "RESTORED") else v
        }
    }

    private fun restorable() = items.values.filter { it.status == "APPLIED" && it.action in setOf("DISABLE", "REMOVE") }

    override fun observeBatches(): Flow<List<BatchWithItems>> = flowOf(batches.values.map { b -> BatchWithItems(b, items.values.filter { it.batchId == b.id }) })
    override suspend fun recentBatches(limit: Int): List<BatchWithItems> = batches.values.take(limit).map { b -> BatchWithItems(b, items.values.filter { it.batchId == b.id }) }
    override suspend fun appliedRestorable(): List<ItemEntity> = restorable().sortedByDescending { it.id }
    override suspend fun appliedInBatch(batchId: Long): List<ItemEntity> = restorable().filter { it.batchId == batchId }
    override suspend fun appliedForPackage(pkg: String): List<ItemEntity> = restorable().filter { it.pkg == pkg }
    override fun observeRestorableCount(): Flow<Int> = flowOf(restorable().size)
    override suspend fun deleteBatch(id: Long) { batches.remove(id); items.values.removeAll { it.batchId == id } }
    override suspend fun clearAll() { batches.clear(); items.clear() }
}
