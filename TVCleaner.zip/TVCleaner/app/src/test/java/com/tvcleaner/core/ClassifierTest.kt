package com.tvcleaner.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ClassifierTest {
    private val c = TestDb.classifier

    private fun risk(pkg: String) = c.classify(pkg).risk

    @Test fun coreSystemPackagesAreProtected() {
        listOf(
            "com.google.android.gms", "com.android.vending", "com.android.systemui", "com.google.android.webview",
            "com.android.tv.settings", "com.google.android.tvlauncher", "com.google.android.apps.tv.launcherx",
            "com.android.shell", "android",
        ).forEach { assertEquals(it, Risk.PROTECTED, risk(it)) }
    }

    @Test fun vendorChipsetServicesAreProtected() {
        listOf(
            "com.mediatek.tvinput", "com.mediatek.wwtv.tvcenter", "com.realtek.dtv", "com.amlogic.tvservice",
            "com.droidlogic.tv.settings", "com.hisilicon.tuner",
        ).forEach { assertEquals(it, Risk.PROTECTED, risk(it)) }
    }

    @Test fun inputAndTunerServicesAreProtectedByName() {
        assertEquals(Risk.PROTECTED, risk("com.sony.dtv.tvinput.dvbtuner"))
        assertEquals(Risk.PROTECTED, risk("com.hisense.tv.hitvinput"))
        assertEquals(Risk.PROTECTED, risk("com.someoem.tuner.service"))
        assertEquals(Risk.PROTECTED, risk("com.someoem.bluetooth.remote"))
    }

    @Test fun protectedFlagIsNotSelectable() {
        assertFalse(c.classify("com.android.vending").selectable)
        assertTrue(c.classify("tv.samba.ssm").selectable)
    }

    @Test fun knownBloatIsSafeAndFlagged() {
        val samba = c.classify("tv.samba.ssm")
        assertEquals(Risk.SAFE, samba.risk)
        assertTrue(Flag.ACR_TRACKING in samba.flags)

        assertTrue(Flag.RETAIL_DEMO in c.classify("com.sony.dtv.demomode").flags)
        assertTrue(Flag.PROMO in c.classify("com.sony.dtv.promos").flags)
        assertTrue(Flag.FACTORY_TEST in c.classify("com.at.factory").flags)
        assertTrue(Flag.APP_STORE in c.classify("org.droidtv.nettv.market").flags)
    }

    @Test fun factoryToolsOnHaierBoardsAreProtected() {
        assertEquals(Risk.PROTECTED, risk("com.cvte.tv.fac.menu"))
        assertEquals(Risk.PROTECTED, risk("mediatek.factorymenu.ui"))
    }

    @Test fun unlistedVendorPackagesAreTestNotSafe() {
        val r = c.classify("com.tcl.somethingnew")
        assertEquals(Risk.TEST, r.risk)
        assertTrue(r.known)
    }

    @Test fun nameHeuristicsAddFlagsToUnknownPackages() {
        val r = c.classify("com.example.storedemo")
        assertTrue(Flag.RETAIL_DEMO in r.flags)
        assertEquals(Risk.TEST, r.risk)
    }

    @Test fun completelyUnknownPackageIsUnknown() {
        val r = c.classify("com.example.randomapp")
        assertEquals(Risk.UNKNOWN, r.risk)
        assertFalse(r.known)
        assertEquals("Randomapp", r.name)
    }

    @Test fun activeLauncherIsProtectedDynamically() {
        val dyn = c.withDynamicProtection(mapOf("com.example.mylauncher" to "Active home launcher"))
        val r = dyn.classify("com.example.mylauncher")
        assertEquals(Risk.PROTECTED, r.risk)
        assertEquals("Active home launcher", r.dynamicReason)
        // The original classifier is unchanged.
        assertEquals(Risk.UNKNOWN, c.classify("com.example.mylauncher").risk)
    }

    @Test fun dynamicProtectionBeatsSafeEntry() {
        val dyn = c.withDynamicProtection(mapOf("com.google.android.youtube.tvmusic" to "Active home launcher"))
        assertEquals(Risk.PROTECTED, dyn.classify("com.google.android.youtube.tvmusic").risk)
    }

    @Test fun protectedPatternBeatsExactSafeEntry() {
        val db = PackageDb(
            entries = listOf(DbEntry("com.mediatek.fake", "Fake", Risk.SAFE, "x", emptySet(), emptySet())),
            patterns = listOf(DbPattern(PatternType.PREFIX, "com.mediatek.", Risk.PROTECTED, "vendor", emptySet(), emptySet())),
        )
        assertEquals(Risk.PROTECTED, Classifier(db).classify("com.mediatek.fake").risk)
    }

    @Test fun mostRestrictivePatternWinsWhenNoExactEntry() {
        val db = PackageDb(
            entries = emptyList(),
            patterns = listOf(
                DbPattern(PatternType.PREFIX, "com.a.", Risk.TEST, "t", emptySet(), emptySet()),
                DbPattern(PatternType.CONTAINS, "tuner", Risk.PROTECTED, "p", emptySet(), emptySet()),
            ),
        )
        assertEquals(Risk.PROTECTED, Classifier(db).classify("com.a.tuner").risk)
        assertEquals(Risk.TEST, Classifier(db).classify("com.a.other").risk)
    }

    @Test fun friendlyNameFallbacks() {
        assertEquals("Promos", Classifier.friendlyName("com.sony.dtv.promos"))
        assertEquals("Foo service", Classifier.friendlyName("com.example.foo.service"))
        assertEquals("Bt pair tips", Classifier.friendlyName("com.example.bt_pair_tips"))
    }
}
