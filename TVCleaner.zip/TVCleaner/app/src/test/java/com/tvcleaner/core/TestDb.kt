package com.tvcleaner.core

import java.io.File

/** Loads the real bundled database for tests (Gradle runs unit tests with the module dir as working dir). */
object TestDb {
    val file: File = listOf(
        File("src/main/assets/package_db.json"),
        File("app/src/main/assets/package_db.json"),
    ).first { it.exists() }

    val db: PackageDb by lazy { PackageDbParser.parse(file.readText()) }
    val classifier: Classifier by lazy { Classifier(db) }
}
