package com.tvcleaner.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class CommandBuilderTest {
    private val pkg = "com.example.app"

    private fun rejects(block: () -> Unit) {
        try {
            block()
            fail("expected IllegalArgumentException")
        } catch (_: IllegalArgumentException) {
        }
    }

    @Test fun scanCommands() {
        assertEquals("pm list packages -s", CommandBuilder.LIST_SYSTEM)
        assertEquals("pm list packages -3", CommandBuilder.LIST_THIRD_PARTY)
        assertEquals("pm list packages -d", CommandBuilder.LIST_DISABLED)
        assertTrue(CommandBuilder.RESOLVE_HOME.contains("android.intent.category.HOME"))
    }

    @Test fun disableCommand() = assertEquals("pm disable-user --user 0 $pkg", CommandBuilder.disable(pkg))
    @Test fun removeCommand() = assertEquals("pm uninstall -k --user 0 $pkg", CommandBuilder.remove(pkg))
    @Test fun enableCommand() = assertEquals("pm enable --user 0 $pkg", CommandBuilder.enable(pkg))
    @Test fun installExistingCommand() = assertEquals("cmd package install-existing $pkg", CommandBuilder.installExisting(pkg))
    @Test fun forceStopCommand() = assertEquals("am force-stop $pkg", CommandBuilder.forceStop(pkg))
    @Test fun clearDataCommand() = assertEquals("pm clear $pkg", CommandBuilder.clearData(pkg))
    @Test fun clearCacheCommand() = assertEquals("pm clear --cache-only $pkg", CommandBuilder.clearCache(pkg))
    @Test fun trimCachesCommand() = assertEquals("pm trim-caches 999G", CommandBuilder.TRIM_CACHES)

    @Test fun rejectsShellInjection() {
        listOf("com.x; rm -rf /", "com.x && reboot", "com.x\$(id)", "com.x`id`", "", "com..x", "com.x y", "../etc", "com.x\nreboot")
            .forEach { bad ->
                rejects { CommandBuilder.disable(bad) }
                rejects { CommandBuilder.remove(bad) }
                rejects { CommandBuilder.enable(bad) }
                rejects { CommandBuilder.stepsFor(CleanAction.CLEAR_DATA, bad) }
            }
    }

    @Test fun acceptsRealisticPackageNames() {
        listOf("android", "com.google.android.tvlauncher", "air.com.vudu.air.DownloaderTablet", "org.droidtv.nettvapp20004410", "mediatek.factorymenu.ui")
            .forEach { assertTrue(it, CommandBuilder.isValidPackage(it)) }
        assertFalse(CommandBuilder.isValidPackage("1com.bad"))
    }

    @Test fun animationScaleStepsCoverAllThreeSettings() {
        val steps = CommandBuilder.animationSteps(0.5f).map { it.command }
        assertEquals(
            listOf(
                "settings put global window_animation_scale 0.5",
                "settings put global transition_animation_scale 0.5",
                "settings put global animator_duration_scale 0.5",
            ),
            steps,
        )
        assertEquals("0.3", CommandBuilder.formatScale(0.3f))
        assertEquals("1.0", CommandBuilder.formatScale(1.0f))
    }

    @Test fun animationScaleRejectsBadInput() {
        rejects { CommandBuilder.animationSteps(-1f) }
        rejects { CommandBuilder.getAnimationScale("evil; reboot") }
    }

    @Test fun stepsPerAction() {
        assertEquals(listOf(ShellStep("pm disable-user --user 0 $pkg", StepKind.DISABLE)), CommandBuilder.stepsFor(CleanAction.DISABLE, pkg))
        assertEquals(listOf(ShellStep("pm uninstall -k --user 0 $pkg", StepKind.UNINSTALL)), CommandBuilder.stepsFor(CleanAction.REMOVE, pkg))
        assertEquals(StepKind.FORCE_STOP, CommandBuilder.stepsFor(CleanAction.FORCE_STOP, pkg).single().kind)
    }

    @Test fun restoreStepsUndoDisableAndRemove() {
        assertEquals(listOf(ShellStep("pm enable --user 0 $pkg", StepKind.ENABLE)), CommandBuilder.restoreSteps(CleanAction.DISABLE, pkg))
        val remove = CommandBuilder.restoreSteps(CleanAction.REMOVE, pkg)
        assertEquals("cmd package install-existing $pkg", remove[0].command)
        assertTrue(remove[0].required)
        assertEquals("pm enable --user 0 $pkg", remove[1].command)
        assertFalse(remove[1].required)
        assertTrue(CommandBuilder.restoreSteps(CleanAction.CLEAR_DATA, pkg).isEmpty())
    }

    @Test fun exitMarkerWrapper() {
        val wrapped = CommandBuilder.withExitMarker("pm list packages -3")
        assertEquals("pm list packages -3; echo \"__tvc_rc=\$?\"", wrapped)
    }

    @Test fun filePathsAreValidated() {
        assertEquals("exec:cat /system/app/Foo/Foo.apk", CommandBuilder.execCat("/system/app/Foo/Foo.apk"))
        rejects { CommandBuilder.execCat("/system/app/Foo.apk; id") }
        rejects { CommandBuilder.fileSize("relative/path") }
    }
}
