package com.tvcleaner.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ShellParserTest {
    @Test fun parsesPackageList() {
        val out = "package:com.google.android.gms\r\npackage:com.tcl.tv\r\nnoise\r\npackage:/x/base.apk=com.foo.bar\r\n"
        assertEquals(setOf("com.google.android.gms", "com.tcl.tv", "com.foo.bar"), ShellParser.parsePackages(out))
    }

    @Test fun ignoresInvalidPackageLines() {
        assertTrue(ShellParser.parsePackages("package:bad name\npackage:\n").isEmpty())
    }

    @Test fun splitsExitMarker() {
        assertEquals("hello" to 0, ShellParser.splitExit("hello\r\n__tvc_rc=0\r\n"))
        assertEquals("Failure [x]" to 1, ShellParser.splitExit("Failure [x]\n__tvc_rc=1"))
        assertEquals("partial" to null, ShellParser.splitExit("partial\r\n"))
        assertEquals("no newline" to 127, ShellParser.splitExit("no newline__tvc_rc=127\n"))
    }

    @Test fun parsesGetpropAndBuildsTvInfo() {
        val out = """
            [ro.product.manufacturer]: [TCL]
            [ro.product.brand]: [TCL]
            [ro.product.model]: [55C735]
            [ro.product.device]: [G07]
            [ro.build.version.release]: [12]
            [ro.build.version.sdk]: [31]
            [ro.build.display.id]: [TTE1.230101]
        """.trimIndent()
        val tv = ShellParser.parseTvInfo(ShellParser.parseGetprop(out))
        assertEquals(Brand.TCL, tv.brand)
        assertEquals("55C735", tv.model)
        assertEquals(31, tv.sdk)
        assertEquals("Android 12 (API 31)", tv.androidText)
        assertEquals("TCL", tv.displayBrand)
    }

    @Test fun unknownBrandFallsBackToPropertyName() {
        val tv = ShellParser.parseTvInfo(mapOf("ro.product.brand" to "Acme", "ro.product.model" to "X1"))
        assertEquals(Brand.OTHER, tv.brand)
        assertEquals("Acme", tv.displayBrand)
    }

    @Test fun resolvesHomeLauncher() {
        val out = "priority=0 preferredOrder=0 match=0x108000 specificIndex=-1 isDefault=true\r\ncom.google.android.tvlauncher/.MainActivity\r\n"
        assertEquals("com.google.android.tvlauncher", ShellParser.parseHomePackage(out))
    }

    @Test fun chooserIsNotALauncher() {
        assertNull(ShellParser.parseHomePackage("android/com.android.internal.app.ResolverActivity"))
        assertNull(ShellParser.parseHomePackage("No activity found"))
    }

    @Test fun parsesHomeCandidates() {
        val out = "2 activities found:\n  priority=0\n  com.a.launcher/.Main\n  com.b.setup/com.b.setup.Recovery\n"
        assertEquals(setOf("com.a.launcher", "com.b.setup"), ShellParser.parseHomeCandidates(out))
    }

    @Test fun parsesAnimationScale() {
        assertEquals(0.5f, ShellParser.parseScale("0.5\n")!!, 0.0001f)
        assertNull(ShellParser.parseScale("null\n"))
    }

    @Test fun parsesProcessList() {
        val out = """
            PID RSS NAME
            1 2000 init
            812 54000 com.google.android.tvlauncher
            900 12000 com.google.android.gms:persistent
            901 8000 com.google.android.gms
            950 100 /system/bin/surfaceflinger
        """.trimIndent()
        val list = ShellParser.parseProcesses(out)
        assertEquals(listOf("com.google.android.tvlauncher", "com.google.android.gms"), list.map { it.pkg })
        assertEquals(20000L, list.first { it.pkg == "com.google.android.gms" }.rssKb)
    }

    @Test fun disableOutcome() {
        assertTrue(ShellParser.outcome(StepKind.DISABLE, "Package com.x new state: disabled-user", 0).success)
        val denied = ShellParser.outcome(StepKind.DISABLE, "java.lang.SecurityException: Shell cannot change component state for com.x/.A to 3", 255)
        assertFalse(denied.success)
        assertTrue(denied.message.startsWith("Blocked by the TV"))
        assertFalse(ShellParser.outcome(StepKind.DISABLE, "", 0).success)
    }

    @Test fun enableOutcome() {
        assertTrue(ShellParser.outcome(StepKind.ENABLE, "Package com.x new state: enabled", 0).success)
        assertFalse(ShellParser.outcome(StepKind.ENABLE, "Error: java.lang.IllegalArgumentException: Unknown package: com.x", 1).success)
    }

    @Test fun uninstallOutcome() {
        assertTrue(ShellParser.outcome(StepKind.UNINSTALL, "Success", 0).success)
        val f = ShellParser.outcome(StepKind.UNINSTALL, "Failure [DELETE_FAILED_DEVICE_POLICY_MANAGER]", 1)
        assertFalse(f.success)
        assertEquals("Blocked by device policy on the TV.", f.message)
    }

    @Test fun installExistingOutcome() {
        assertTrue(ShellParser.outcome(StepKind.INSTALL_EXISTING, "Package com.x installed for user: 0", 0).success)
        assertFalse(ShellParser.outcome(StepKind.INSTALL_EXISTING, "Failure [INSTALL_FAILED_INVALID_URI]", 1).success)
    }

    @Test fun silentCommandsSucceedOnExitZero() {
        assertTrue(ShellParser.outcome(StepKind.FORCE_STOP, "", 0).success)
        assertTrue(ShellParser.outcome(StepKind.SET_SETTING, "", null).success)
        assertFalse(ShellParser.outcome(StepKind.FORCE_STOP, "", 1).success)
    }

    @Test fun clearCacheUnsupportedMessage() {
        val o = ShellParser.outcome(StepKind.CLEAR_CACHE, "Error: Unknown option: --cache-only", 1)
        assertFalse(o.success)
        assertEquals("Not supported by this Android version.", o.message)
    }
}
