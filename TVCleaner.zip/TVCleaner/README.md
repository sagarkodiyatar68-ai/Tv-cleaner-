# TV Cleaner

Android app (Kotlin, Jetpack Compose, Material 3) that runs on your **phone** and cleans an **Android TV** over the
network with the ADB protocol. No laptop and no root.

- minSdk 26, targetSdk/compileSdk 34, Kotlin 2.0.21, AGP 8.5.2, Gradle 8.9
- Tabs: **Connect**, **Scan**, **History / Restore**, **Tweaks**
- Dark theme by default, no ads, no analytics

> **Read this first: what was and was not verified**
>
> The code was written in an environment with no Android SDK, so **I could not run `./gradlew assembleDebug`, install
> the APK, or test against a real TV.**
>
> Verified there:
> - The pure-Kotlin core (classifier, command builders, parsers, report) and the apply/restore logic (run against a
>   fake TV and an in-memory DAO) compiled with `kotlinc` 2.0.21 and **82 unit tests passed**, run through a small
>   JUnit shim. The test sources are standard JUnit 4.
> - The ADB, credential, data, domain and ViewModel code was type-checked against the real API 34 `android.jar`, the real
>   `sun-security-android` sources, and stubs that copy the real libadb-android 3.1.1 signatures.
>
> Not verified: the Gradle build as a whole, the Compose UI (hand-reviewed only), Room/KSP code generation,
> JitPack resolving the three JitPack dependencies, libadb-android's TLS/pairing against real TVs, and how each TV
> brand reacts to each command. Expect to fix a few small things on first build.

## Choosing the ADB library

I checked both candidates by reading their current source (not just READMEs):

| | **dadb** (mobile-dev-inc) | **libadb-android** (MuntashirAkon) |
|---|---|---|
| Version checked | 2.0.0 (Maven Central, released 2026-06-22) | 3.1.1 (JitPack, last commit 2025-12-08) |
| RSA key auth | Yes (`AdbKeyPair`) | Yes (you supply key + certificate) |
| TLS (`A_STLS`, wireless debugging port) | **No** (no TLS code in the source) | Yes |
| Wireless-debugging pairing (6-digit code) | **No** | Yes (`pair(host, port, code)`) |
| Shell v2 exit codes | Yes | No (plain `shell:` service) |
| Licence | Apache-2.0 | GPL-3.0-or-later **or** Apache-2.0 (your choice) |

**Chosen: libadb-android 3.1.1.** The spec needs Android 11+ wireless-debugging pairing, and dadb cannot do it. The cost:
no exit codes, so every command is sent as `cmd; echo "__tvc_rc=$?"` and the code is parsed back out
(`ShellParser.splitExit`). dadb would still be a good fit for TVs that only offer classic `adb tcpip` on 5555.

Other dependencies: `sun-security-android` 1.1 (builds the self-signed X.509 certificate libadb needs; GPLv2 **with
Classpath Exception**) and `conscrypt-android` 2.5.3 (TLS 1.3 + exported keying material, needed for pairing/TLS).
All three of libadb-android, sun-security-android and its `spake2-android` dependency come from **JitPack**.

## Limitations

- **Pairing/TLS depends on libadb-android and is untested by me on real TVs.** Google has also announced changes to
  wireless ADB for Android 17 ("ADB Wi-Fi 2.0"); I did not verify compatibility.
- **No mDNS auto-discovery.** The wireless-debugging port is random on every toggle, so you type the IP and port the TV
  shows. (libadb's own discovery is reported unreliable; I left it out rather than ship something flaky.)
- Many TVs never show a "Wireless debugging" entry. They offer plain **USB debugging** (which opens port 5555) instead.
  Some budget firmwares offer neither; nothing can be done from the app then.
- **Exit codes are reconstructed** from an `echo $?` marker plus output text, because plain `shell:` has no exit status.
- **App names/icons** come from copying each APK off the TV (40 MB cap, one at a time, cached on the phone) and reading
  it with the phone's PackageManager. When that fails you see the DB name or a name derived from the package.
- "Clear cache" uses `pm clear --cache-only`, which needs **Android 12+** on the TV (otherwise it reports "not
  supported"). "Clear data" works everywhere and cannot be undone.
- Apps removed with `pm uninstall -k --user 0` no longer appear in a scan. Bring them back from **History / Restore**
  (`cmd package install-existing`, then `pm enable`).
- Some firmwares block `pm disable-user` for specific packages (`SecurityException`). They show as failed, nothing else
  breaks. OTAs and factory resets can re-enable disabled apps.
- Only the **active launcher** is protected dynamically (plus known launchers in the DB). If Android can't tell which
  launcher is active, every HOME-capable app is protected for that scan.
- The package database is **best-effort community knowledge**: 391 entries and 51 patterns across the requested brands, not
  verified on every firmware. Unlisted vendor packages are TEST, unknown packages are UNKNOWN, never SAFE.
- ADB over the network stays on until you turn debugging off. Turn it off after cleaning.

## Build

Requirements: JDK 17 (Android Studio bundles one), Android SDK Platform 34, and internet access for the first sync
(Google Maven, Maven Central, JitPack).

**Android Studio:** *File > Open*, pick the `TVCleaner` folder, let Gradle sync, then press Run, or
*Build > Build Bundle(s) / APK(s) > Build APK(s)*.

**Command line:**

```bash
# point Gradle at the SDK once (or set ANDROID_HOME)
echo "sdk.dir=/path/to/Android/Sdk" > local.properties

./gradlew assembleDebug          # Windows: gradlew.bat assembleDebug
./gradlew testDebugUnitTest      # unit tests
```

**No computer? Build it on GitHub:** create a free GitHub repository, upload the contents of this folder (keep the
`.github` folder), open the **Actions** tab, choose **Build APK**, tap **Run workflow**, then download the
`TVCleaner-debug-apk` artifact when it finishes. The debug APK is signed automatically and installs directly.
If the build fails, the log shows the exact error.

**APK output:** `app/build/outputs/apk/debug/app-debug.apk`
(`./gradlew assembleRelease` gives `app/build/outputs/apk/release/app-release-unsigned.apk`; sign it before installing.)

Install by copying the APK to the phone, or `adb install app/build/outputs/apk/debug/app-debug.apk`.

## Using it

1. **Connect tab.** Follow the on-screen steps to enable Developer options and USB / Wireless debugging on the TV.
   Enter the TV's IP and port (default 5555). For Android 11+ wireless debugging, expand the pairing section and enter
   the pairing port and 6-digit code from *Pair device with pairing code*, with the main Wireless debugging port in the
   Port field. Accept **Allow USB debugging?** on the TV and tick *Always allow*.
2. **Scan tab.** Shows brand, model and Android version, then every system / user / disabled app with name, icon (if
   loaded), risk chip and flags. Filter by risk, scope or flag, search, or **Select all SAFE**.
3. Choose **Disable** (default, reversible), or use the menu for Remove, Force stop, Clear cache, Clear data. A
   confirmation dialog lists every app with its risk. Changes run **one app at a time** with live per-app results and a
   Stop button. **Safe mode** limits everything to SAFE items.
4. **History / Restore tab.** The restore list is written **before** the first command runs. Restore a whole batch or
   **Restore all**.
5. **Tweaks tab.** Trim caches, animation scale 0.3x / 0.5x / 1x, list and stop background apps.
6. **Share report** (Scan tab, top right) sends a plain-text TV report through the system share sheet.

## Safety design

- PROTECTED apps cannot be selected: launchers, Google Play services, Play Store, SystemUI, WebView, TV settings,
  MediaTek / Realtek / Amlogic / HiSilicon / MStar / Qualcomm vendor services, TV input and tuner services, Bluetooth and
  remote-pairing services, content providers, and known factory tools.
- A PROTECTED pattern **overrides** a SAFE database entry (a unit test enforces that no SAFE entry matches one).
- The active launcher is read from the TV during the scan and again right before Disable / Remove.
- Package names are validated against a strict regex before any command is built, so nothing can be injected into the
  shell.
- The app refuses non-local hosts (private IPv4, link-local, ULA, `.local`).

## Package database

`app/src/main/assets/package_db.json`

- `packages[]`: `pkg`, `name`, `risk` (`SAFE` / `TEST` / `PROTECTED`), `desc`, `brands`, `flags`.
- `patterns[]`: `type` (`prefix` / `contains` / `regex`), `value`, `risk`, `desc`, `brands`, `flags`.
- Risk: **SAFE** = commonly disabled without breaking core functions (ACR/tracking, retail demo, promo, preinstalled
  stores and unused apps). **TEST** = may affect a feature, change in small batches. **UNKNOWN** = not in the database.
  **PROTECTED** = never selectable.
- Flags: `ACR_TRACKING`, `RETAIL_DEMO`, `PROMO`, `APP_STORE`, `FACTORY_TEST`.
- Brand tags: ALL, Haier, TCL, Xiaomi, Sony, Hisense, Philips, Nvidia Shield, Chromecast with Google TV.
- Package names were cross-checked against community lists (Gathin23/tv-vibehack, MIT). Descriptions marked "Likely" are
  inferred from the package name.

`PackageDbTest` fails the build if the database drops below 150 entries, has duplicates or invalid names, lacks a brand
or flag, or contains a SAFE entry covered by a PROTECTED pattern.

## Project layout

```
app/src/main/java/com/tvcleaner/
  core/     pure Kotlin: Model, Classifier, CommandBuilder, ShellParser, HostValidator, MiniJson, ReportBuilder
  adb/      TvSession (connect, pair, shell, pull), TvAdbConnectionManager, AdbFailure
  data/     CredentialStore (Keystore-wrapped key), SettingsStore (DataStore), db/ (Room: batches, items)
  domain/   TvRepository (scan, apply, restore, tweaks), IconRepository
  ui/       AppRoot, ViewModels, ApplyRunner, theme/, components/, connect/, scan/, history/, tweaks/
app/src/main/assets/package_db.json
app/src/test/                      classifier, DB integrity, commands, parsers, repository (fake TV)
```

## Privacy

- No ads, analytics, crash reporting or telemetry, and no cloud endpoints.
- Permissions: `INTERNET` and `ACCESS_NETWORK_STATE` only. Android requires `INTERNET` for any raw TCP socket, even on
  your own Wi-Fi. The app opens connections only to the private address you type in.
- Stored on the phone only: the TV's IP/port, the ADB key (encrypted with an Android Keystore AES-256 key, in
  no-backup storage, never exported), the restore history (Room) and an icon cache. Pairing codes are never saved.
- Backups are disabled (`allowBackup=false`). Sharing a report happens only when you tap Share.

## Third-party licences

libadb-android (GPL-3.0-or-later or Apache-2.0; use the Apache-2.0 option), sun-security-android (GPLv2 with Classpath
Exception), Conscrypt (Apache-2.0), BouncyCastle and spake2-android (transitive via libadb-android), AndroidX /
Compose / Room / DataStore / kotlinx.coroutines (Apache-2.0). Check the terms before you distribute the app.
